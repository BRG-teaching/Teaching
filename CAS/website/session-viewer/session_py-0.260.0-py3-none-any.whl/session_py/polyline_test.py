from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all
from .tolerance import TOLERANCE
from .tolerance import Tolerance
import math


@MINI_TEST("Polyline", "Constructor")
def test_polyline_constructor():
    from session_py import Polyline
    from session_py import Point
    from session_py import Vector
    from session_py import Color

    p0 = Point(0.0, 0.0, 0.0)
    p1 = Point(1.0, 0.0, 0.0)
    p2 = Point(1.0, 1.0, 0.0)
    p3 = Point(0.0, 1.0, 0.0)
    pl = Polyline([p0, p1, p2, p3])
    point_count = len(pl)
    segment_count = pl.segment_count()
    is_empty = pl.is_empty()
    pt = pl.get_point(1)
    pt_idx = pl[1]
    pl_copy = pl.duplicate()
    pl_copy.set_point(0, Point(5.0, 6.0, 7.0))
    plstr = str(pl)
    plrepr = repr(pl)
    plcopy = pl.duplicate()
    plother = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )

    plmult = pl.duplicate()
    plmult *= 2.0
    pldiv = pl.duplicate()
    pldiv /= 2.0
    pladd = pl.duplicate()
    pladd += Vector(1.0, 1.0, 1.0)
    plsub = pl.duplicate()
    plsub -= Vector(1.0, 1.0, 1.0)

    rmul = pl * 2.0
    rdiv = pl / 2.0
    radd = pl + Vector(1.0, 1.0, 1.0)
    rdif = pl - Vector(1.0, 1.0, 1.0)

    plneg = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(3.0, 0.0, 0.0),
        ]
    )
    neg = -plneg

    plc = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    plc.linecolor = Color(1.0, 0.0, 0.0, 1.0, "red")
    plc.width = 2.5

    MINI_CHECK(pl.name == "my_polyline" and pl.guid != "" and point_count == 4)
    MINI_CHECK(segment_count == 3 and not is_empty)
    MINI_CHECK(pt[0] == 1.0 and pt[1] == 0.0 and pt[2] == 0.0)
    MINI_CHECK(pt_idx[0] == 1.0 and pl_copy[0][0] == 5.0 and pl_copy[0][1] == 6.0)
    MINI_CHECK("(0.0, 0.0, 0.0)" in plstr)
    MINI_CHECK("Polyline(my_polyline" in plrepr)
    MINI_CHECK("4 points" in plrepr)
    MINI_CHECK(plcopy == plother)
    MINI_CHECK(plcopy.guid != pl.guid)
    MINI_CHECK(plmult.get_point(1)[0] == 2.0)
    MINI_CHECK(pldiv.get_point(1)[0] == 0.5)
    MINI_CHECK(pladd.get_point(0)[0] == 1.0 and pladd.get_point(0)[1] == 1.0)
    MINI_CHECK(plsub.get_point(0)[0] == -1.0 and plsub.get_point(0)[1] == -1.0)
    MINI_CHECK(rmul.get_point(1)[0] == 2.0)
    MINI_CHECK(rdiv.get_point(1)[0] == 0.5)
    MINI_CHECK(radd.get_point(0)[0] == 1.0 and radd.get_point(0)[1] == 1.0)
    MINI_CHECK(rdif.get_point(0)[0] == -1.0 and rdif.get_point(0)[1] == -1.0)
    MINI_CHECK(neg.get_point(0)[0] == 3.0 and neg.get_point(3)[0] == 0.0)
    MINI_CHECK(plc.linecolor[0] == 1.0 and plc.linecolor[1] == 0.0 and plc.width == 2.5)


@MINI_TEST("Polyline", "From Coords")
def test_polyline_from_coords():
    from session_py import Polyline

    coords = [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0]
    pl = Polyline.from_coords(coords)

    MINI_CHECK(pl.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(0)[0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(1)[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(2)[1], 1.0))


@MINI_TEST("Polyline", "From Sides")
def test_polyline_from_sides():
    from session_py import Polyline

    sq = Polyline.from_sides(4, 1.0, False)
    sq_closed = Polyline.from_sides(4, 1.0, True)

    MINI_CHECK(sq.point_count() == 4)
    MINI_CHECK(sq_closed.point_count() == 5)
    MINI_CHECK(sq_closed.is_closed())


@MINI_TEST("Polyline", "Rectangle")
def test_polyline_rectangle():
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    o = Point(0, 0, 0)
    r = Polyline.rectangle(o, Vector.x_axis(), Vector.y_axis(), 2.0, 1.0, True)

    MINI_CHECK(r.point_count() == 5)
    MINI_CHECK(r.is_closed())
    MINI_CHECK(TOLERANCE.is_close(r.get_point(2)[0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(r.get_point(2)[1], 1.0))


@MINI_TEST("Polyline", "Transformation")
def test_polyline_transformation():
    from session_py import Polyline
    from session_py import Point
    from session_py import Xform

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    pl_xf = Xform.translation(10.0, 0.0, 0.0)
    pl_transformed = pl.transformed(pl_xf)
    pl.transform(pl_xf)

    MINI_CHECK(
        pl_transformed.get_point(0)[0] == 10.0
        and pl_transformed.get_point(1)[0] == 11.0
    )
    MINI_CHECK(pl.get_point(0)[0] == 10.0 and pl.get_point(1)[0] == 11.0)


@MINI_TEST("Polyline", "Json Roundtrip")
def test_polyline_json_roundtrip():
    from session_py import Polyline
    from session_py import Point
    from pathlib import Path

    pl = Polyline(
        [
            Point(1.0, 2.0, 3.0),
            Point(4.0, 5.0, 6.0),
            Point(7.0, 8.0, 9.0),
            Point(10.0, 11.0, 12.0),
        ]
    )
    pl.name = "test_polyline"
    pl.dash = [3.0, 2.0]

    j = pl.__jsondump__()
    loaded_j = Polyline.__jsonload__(j)

    s = pl.file_json_dumps()
    loaded_s = Polyline.file_json_loads(s)

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_polyline.json"
    pl.file_json_dump(fname)
    loaded = Polyline.file_json_load(fname)

    MINI_CHECK(loaded_j.name == "test_polyline")
    MINI_CHECK(TOLERANCE.is_close(loaded_j.get_point(0)[0], 1.0))
    MINI_CHECK(loaded_s.name == "test_polyline")
    MINI_CHECK(TOLERANCE.is_close(loaded_s.get_point(0)[0], 1.0))
    MINI_CHECK(loaded.name == "test_polyline")
    MINI_CHECK(len(loaded) == 4)
    MINI_CHECK(TOLERANCE.is_close(loaded.get_point(0)[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(loaded.get_point(1)[1], 5.0))
    MINI_CHECK(TOLERANCE.is_close(loaded.get_point(2)[2], 9.0))
    MINI_CHECK(loaded.dash == [3.0, 2.0])
    MINI_CHECK(loaded.guid == pl.guid)


@MINI_TEST("Polyline", "Protobuf Roundtrip")
def test_polyline_protobuf_roundtrip():
    from session_py import Polyline
    from session_py import Point
    from pathlib import Path

    pl = Polyline(
        [
            Point(1.0, 2.0, 3.0),
            Point(4.0, 5.0, 6.0),
            Point(7.0, 8.0, 9.0),
            Point(10.0, 11.0, 12.0),
        ]
    )
    pl.name = "test_polyline"
    pl.dash = [3.0, 2.0]

    guid = pl.guid
    s = pl.pb_dumps()
    loaded_s = Polyline.pb_loads(s)

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_polyline.bin"
    pl.pb_dump(fname)
    loaded = Polyline.pb_load(fname)
    converted = Polyline.from_proto(pl.to_proto())

    MINI_CHECK(loaded_s.name == "test_polyline")
    MINI_CHECK(TOLERANCE.is_close(loaded_s.get_point(0)[0], 1.0))
    MINI_CHECK(loaded_s.guid == guid)
    MINI_CHECK(loaded.name == "test_polyline")
    MINI_CHECK(len(loaded) == 4)
    MINI_CHECK(TOLERANCE.is_close(loaded.get_point(0)[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(loaded.get_point(1)[1], 5.0))
    MINI_CHECK(TOLERANCE.is_close(loaded.get_point(2)[2], 9.0))
    MINI_CHECK(loaded.dash == [3.0, 2.0])
    MINI_CHECK(loaded.guid == guid)
    MINI_CHECK(converted == pl)
    MINI_CHECK(converted.guid == guid)


@MINI_TEST("Polyline", "Length")
def test_polyline_length():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    ln = pl.length()
    mag_sq = pl.length_squared()

    MINI_CHECK(TOLERANCE.is_close(ln, 3.0))
    MINI_CHECK(TOLERANCE.is_close(mag_sq, 3.0))


@MINI_TEST("Polyline", "Center")
def test_polyline_center():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
        ]
    )
    c = pl.center()

    MINI_CHECK(TOLERANCE.is_close(c[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(c[1], 1.0))
    MINI_CHECK(TOLERANCE.is_close(c[2], 0.0))


@MINI_TEST("Polyline", "Is Closed")
def test_polyline_is_closed():
    from session_py import Polyline
    from session_py import Point

    open_pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    is_open = open_pl.is_closed()

    closed_pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    is_closed = closed_pl.is_closed()

    MINI_CHECK(not is_open)
    MINI_CHECK(is_closed)


@MINI_TEST("Polyline", "Closed")
def test_polyline_closed():
    from session_py import Polyline
    from session_py import Point

    open_pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    closed_from_open = open_pl.closed()

    closed_pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    closed_from_closed = closed_pl.closed()

    MINI_CHECK(closed_from_open.point_count() == 5)
    MINI_CHECK(closed_from_open.is_closed())
    MINI_CHECK(closed_from_closed.point_count() == 5)
    MINI_CHECK(closed_from_closed.is_closed())


@MINI_TEST("Polyline", "Reverse")
def test_polyline_reverse():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(3.0, 0.0, 0.0),
        ]
    )

    rev = pl.reversed()
    orig_first = pl.get_point(0)[0]
    rev_first = rev.get_point(0)[0]

    pl.reverse()
    in_place_first = pl.get_point(0)[0]

    MINI_CHECK(orig_first == 0.0)
    MINI_CHECK(rev_first == 3.0)
    MINI_CHECK(in_place_first == 3.0)


@MINI_TEST("Polyline", "Closest Point")
def test_polyline_closest_point():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
        ]
    )
    test_pt = Point(1.0, 1.0, 0.0)
    distance, edge_id, closest = pl.closest_distance_and_point(test_pt)

    MINI_CHECK(edge_id == 0)
    MINI_CHECK(TOLERANCE.is_close(closest[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(closest[1], 0.0))
    MINI_CHECK(TOLERANCE.is_close(distance, 1.0))


@MINI_TEST("Polyline", "Closest Point To Line")
def test_polyline_closest_point_to_line():
    from session_py import Polyline
    from session_py import Point

    line_start = Point(0.0, 0.0, 0.0)
    line_end = Point(2.0, 0.0, 0.0)
    pt = Point(1.0, 1.0, 0.0)
    t = Polyline.closest_point_to_line(pt, line_start, line_end)

    MINI_CHECK(TOLERANCE.is_close(t, 0.5))


@MINI_TEST("Polyline", "Line Line Overlap")
def test_polyline_line_line_overlap():
    from session_py import Polyline
    from session_py import Point

    s0 = Point(0.0, 0.0, 0.0)
    e0 = Point(2.0, 0.0, 0.0)
    s1 = Point(1.0, 0.0, 0.0)
    e1 = Point(3.0, 0.0, 0.0)
    result = Polyline.line_line_overlap(s0, e0, s1, e1)

    MINI_CHECK(result is not None)
    MINI_CHECK(TOLERANCE.is_close(result[0][0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(result[1][0], 2.0))

    s2 = Point(5.0, 0.0, 0.0)
    e2 = Point(6.0, 0.0, 0.0)
    no_overlap = Polyline.line_line_overlap(s0, e0, s2, e2)

    MINI_CHECK(no_overlap is None)


@MINI_TEST("Polyline", "Line Line Average")
def test_polyline_line_line_average():
    from session_py import Polyline
    from session_py import Point

    s0 = Point(0.0, 0.0, 0.0)
    e0 = Point(2.0, 0.0, 0.0)
    s1 = Point(0.0, 2.0, 0.0)
    e1 = Point(2.0, 2.0, 0.0)
    os, oe = Polyline.line_line_average(s0, e0, s1, e1)

    MINI_CHECK(TOLERANCE.is_close(os[0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(os[1], 1.0))
    MINI_CHECK(TOLERANCE.is_close(oe[0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(oe[1], 1.0))


@MINI_TEST("Polyline", "Line Line Overlap Average")
def test_polyline_line_line_overlap_average():
    from session_py import Polyline
    from session_py import Point

    s0 = Point(0.0, 0.0, 0.0)
    e0 = Point(2.0, 0.0, 0.0)
    s1 = Point(1.0, 2.0, 0.0)
    e1 = Point(3.0, 2.0, 0.0)
    os, oe = Polyline.line_line_overlap_average(s0, e0, s1, e1)

    MINI_CHECK(TOLERANCE.is_close(os[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(oe[0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(os[1], 1.0))


@MINI_TEST("Polyline", "Line From Projected Points")
def test_polyline_line_from_projected_points():
    from session_py import Polyline
    from session_py import Point

    s = Point(0.0, 0.0, 0.0)
    e = Point(4.0, 0.0, 0.0)
    pts = [
        Point(1.0, 1.0, 0.0),
        Point(3.0, -1.0, 0.0),
    ]
    result = Polyline.line_from_projected_points(s, e, pts)

    MINI_CHECK(result is not None)
    MINI_CHECK(TOLERANCE.is_close(result[0][0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(result[1][0], 3.0))


@MINI_TEST("Polyline", "Point In Polygon 2d")
def test_polyline_point_in_polygon_2d():
    from session_py import Polyline
    from session_py import Point

    sq = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )

    MINI_CHECK(sq.point_in_polygon_2d(Point(0.5, 0.5, 0.0)))
    MINI_CHECK(not sq.point_in_polygon_2d(Point(2.0, 2.0, 0.0)))


@MINI_TEST("Polyline", "Trim Rectangles By Plane")
def test_polyline_trim_rectangles_by_plane():
    from session_py import Plane
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    first = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(4.0, 0.0, 0.0),
            Point(4.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    second = Polyline(
        [
            Point(0.0, 0.0, 1.0),
            Point(4.0, 0.0, 1.0),
            Point(4.0, 1.0, 1.0),
            Point(0.0, 1.0, 1.0),
            Point(0.0, 0.0, 1.0),
        ]
    )
    plane = Plane.from_point_normal(Point(3.0, 0.0, 0.0), Vector(-1.0, 0.0, 0.0))
    ok = Polyline.trim_rectangles_by_plane(first, second, plane)

    MINI_CHECK(ok)
    MINI_CHECK(TOLERANCE.is_close(first[1][0], 3.0))
    MINI_CHECK(TOLERANCE.is_close(first[2][0], 3.0))
    MINI_CHECK(TOLERANCE.is_close(second[1][0], 3.0))
    MINI_CHECK(TOLERANCE.is_close(first[0][0], 0.0))


@MINI_TEST("Polyline", "Extend Segment")
def test_polyline_extend_segment():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(3.0, 0.0, 0.0),
        ]
    )
    pl.extend_segment(0, 0.5, 0.5, 0.0, 0.0)
    first = pl.get_point(0)[0]
    second = pl.get_point(1)[0]

    MINI_CHECK(TOLERANCE.is_close(first, -0.5))
    MINI_CHECK(TOLERANCE.is_close(second, 1.5))


@MINI_TEST("Polyline", "Extend Segment Equally")
def test_polyline_extend_segment_equally():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(3.0, 0.0, 0.0),
        ]
    )
    pl.extend_segment_equally(0, 0.5, 0.0)
    first = pl.get_point(0)[0]
    second = pl.get_point(1)[0]

    ring = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    ring.extend_segment_equally(0, 0.5, 0.0)
    ring.extend_segment_equally(2, 0.5, 0.0)

    MINI_CHECK(TOLERANCE.is_close(first, -0.5))
    MINI_CHECK(TOLERANCE.is_close(second, 1.5))
    MINI_CHECK(ring.is_closed())
    MINI_CHECK(ring.get_point(0) == ring.get_point(3))


@MINI_TEST("Polyline", "Extend Line Segment")
def test_polyline_extend_line_segment():
    from session_py import Polyline
    from session_py import Point

    start = Point(1.0, 0.0, 0.0)
    end = Point(3.0, 0.0, 0.0)
    Polyline.extend_line_segment(start, end, 0.5, 0.5)

    MINI_CHECK(TOLERANCE.is_close(start[0], 0.5))
    MINI_CHECK(TOLERANCE.is_close(end[0], 3.5))


@MINI_TEST("Polyline", "Shrink Line Segment")
def test_polyline_shrink_line_segment():
    from session_py import Polyline
    from session_py import Point

    start = Point(0.0, 0.0, 0.0)
    end = Point(10.0, 0.0, 0.0)
    Polyline.shrink_line_segment(start, end, 0.1)

    MINI_CHECK(TOLERANCE.is_close(start[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(end[0], 9.0))


@MINI_TEST("Polyline", "Get Points")
def test_polyline_get_points():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    points = pl.get_points()

    MINI_CHECK(len(points) == 4)
    MINI_CHECK(
        TOLERANCE.is_close(points[0][0], 0.0) and TOLERANCE.is_close(points[0][1], 0.0)
    )
    MINI_CHECK(
        TOLERANCE.is_close(points[1][0], 1.0) and TOLERANCE.is_close(points[1][1], 0.0)
    )
    MINI_CHECK(
        TOLERANCE.is_close(points[2][0], 1.0) and TOLERANCE.is_close(points[2][1], 1.0)
    )
    MINI_CHECK(
        TOLERANCE.is_close(points[3][0], 0.0) and TOLERANCE.is_close(points[3][1], 1.0)
    )


@MINI_TEST("Polyline", "Get Lines")
def test_polyline_get_lines():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    lines = pl.get_lines()

    MINI_CHECK(len(lines) == 3)
    MINI_CHECK(
        TOLERANCE.is_close(lines[0][0], 0.0) and TOLERANCE.is_close(lines[0][3], 1.0)
    )
    MINI_CHECK(
        TOLERANCE.is_close(lines[1][0], 1.0) and TOLERANCE.is_close(lines[1][4], 1.0)
    )
    MINI_CHECK(
        TOLERANCE.is_close(lines[2][0], 1.0) and TOLERANCE.is_close(lines[2][3], 0.0)
    )


@MINI_TEST("Polyline", "Add Point")
def test_polyline_add_point():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
        ]
    )
    pl.add_point(Point(2.0, 0.0, 0.0))

    MINI_CHECK(pl.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(2)[0], 2.0))


@MINI_TEST("Polyline", "Insert Point")
def test_polyline_insert_point():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
        ]
    )
    pl.insert_point(1, Point(1.0, 0.0, 0.0))

    MINI_CHECK(pl.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(1)[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(2)[0], 2.0))


@MINI_TEST("Polyline", "Remove Point")
def test_polyline_remove_point():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
        ]
    )
    out = pl.remove_point(1)

    MINI_CHECK(out is not None)
    MINI_CHECK(pl.point_count() == 2)
    MINI_CHECK(TOLERANCE.is_close(out[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(1)[0], 2.0))


@MINI_TEST("Polyline", "Shift")
def test_polyline_shift():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(3.0, 0.0, 0.0),
        ]
    )
    pl.shift(1)
    first_after_shift = pl.get_point(0)[0]
    pl.shift(-1)
    first_after_unshift = pl.get_point(0)[0]

    MINI_CHECK(TOLERANCE.is_close(first_after_shift, 1.0))
    MINI_CHECK(TOLERANCE.is_close(first_after_unshift, 0.0))


@MINI_TEST("Polyline", "Point At")
def test_polyline_point_at():
    from session_py import Polyline
    from session_py import Point

    start = Point(0.0, 0.0, 0.0)
    end = Point(2.0, 0.0, 0.0)
    mid = Polyline.point_at(start, end, 0.5)
    quarter = Polyline.point_at(start, end, 0.25)

    MINI_CHECK(TOLERANCE.is_close(mid[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(quarter[0], 0.5))


@MINI_TEST("Polyline", "Is Clockwise")
def test_polyline_is_clockwise():
    from session_py import Polyline
    from session_py import Point
    from session_py import Plane

    cw_pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(0.0, 1.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(1.0, 0.0, 0.0),
        ]
    )
    ccw_pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    plane = Plane()

    MINI_CHECK(cw_pl.is_clockwise(plane))
    MINI_CHECK(not ccw_pl.is_clockwise(plane))


@MINI_TEST("Polyline", "Convex Corners")
def test_polyline_convex_corners():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    corners = pl.get_convex_corners()

    MINI_CHECK(len(corners) == 4)


@MINI_TEST("Polyline", "Tween")
def test_polyline_tween():
    from session_py import Polyline
    from session_py import Point

    pl0 = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    pl1 = Polyline(
        [
            Point(2.0, 0.0, 0.0),
            Point(3.0, 0.0, 0.0),
            Point(3.0, 1.0, 0.0),
            Point(2.0, 1.0, 0.0),
        ]
    )
    tweened = Polyline.tween_two_polylines(pl0, pl1, 0.5)

    MINI_CHECK(TOLERANCE.is_close(tweened.get_point(0)[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(tweened.get_point(1)[0], 2.0))


@MINI_TEST("Polyline", "Average Plane")
def test_polyline_average_plane():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
        ]
    )
    origin, x_axis, y_axis, z_axis = pl.get_average_plane()
    fast_origin, fast_plane = pl.get_fast_plane()

    MINI_CHECK(TOLERANCE.is_close(origin[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(origin[1], 1.0))
    MINI_CHECK(TOLERANCE.is_close(abs(z_axis[2]), 1.0))
    MINI_CHECK(fast_origin[0] >= 0.0)


@MINI_TEST("Polyline", "Interpolate Points")
def test_polyline_interpolate_points():
    from session_py import Polyline
    from session_py import Point

    a = Point(0.0, 0.0, 0.0)
    b = Point(4.0, 0.0, 0.0)

    pts0 = Polyline.interpolate_points(a, b, 3, 0)
    pts1 = Polyline.interpolate_points(a, b, 3, 1)
    pts2 = Polyline.interpolate_points(a, b, 3, 2)

    MINI_CHECK(len(pts0) == 3)
    MINI_CHECK(TOLERANCE.is_close(pts0[0][0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(pts0[1][0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(pts0[2][0], 3.0))
    MINI_CHECK(len(pts1) == 5)
    MINI_CHECK(TOLERANCE.is_close(pts1[0][0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(pts1[4][0], 4.0))
    MINI_CHECK(len(pts2) == 4)
    MINI_CHECK(TOLERANCE.is_close(pts2[0][0], 0.0))


@MINI_TEST("Polyline", "Quick Hull")
def test_polyline_quick_hull():
    from session_py import Polyline
    from session_py import Point

    poly = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
            Point(1.0, 1.0, 0.0),
        ]
    )
    hull = Polyline.quick_hull(poly)

    MINI_CHECK(hull.point_count() == 4)


@MINI_TEST("Polyline", "Bounding Rectangle")
def test_polyline_bounding_rectangle():
    from session_py import Polyline
    from session_py import Point

    poly = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(4.0, 0.0, 0.0),
            Point(4.0, 3.0, 0.0),
            Point(0.0, 3.0, 0.0),
        ]
    )
    rect = Polyline.bounding_rectangle(poly)

    MINI_CHECK(rect is not None and rect.point_count() == 5)
    MINI_CHECK(TOLERANCE.is_close(rect.get_point(0)[2], 0.0))
    MINI_CHECK(TOLERANCE.is_close(rect.get_point(0)[0], rect.get_point(4)[0]))


@MINI_TEST("Polyline", "Grid Of Points In Polygon")
def test_polyline_grid_of_points():
    from session_py import Polyline
    from session_py import Point

    poly = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(4.0, 0.0, 0.0),
            Point(4.0, 4.0, 0.0),
            Point(0.0, 4.0, 0.0),
        ]
    )
    pts = Polyline.grid_of_points_in_polygon(poly, 0.0, 1.0, 100)

    MINI_CHECK(len(pts) > 0)

    for p in pts:
        MINI_CHECK(p[0] >= 0.0 and p[0] <= 4.0)
        MINI_CHECK(p[1] >= 0.0 and p[1] <= 4.0)


@MINI_TEST("Polyline", "Polylabel")
def test_polyline_polylabel():
    from session_py import Polyline
    from session_py import Point

    poly = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(10.0, 0.0, 0.0),
            Point(10.0, 10.0, 0.0),
            Point(0.0, 10.0, 0.0),
        ]
    )
    polys = [poly]
    c, _, r = Polyline.polylabel(polys, 0.5)

    MINI_CHECK(abs(c[0] - 5.0) < 0.6)
    MINI_CHECK(abs(c[1] - 5.0) < 0.6)
    MINI_CHECK(abs(r - 5.0) < 0.6)


@MINI_TEST("Polyline", "Polylabel Circle Division Points")
def test_polyline_polylabel_circle_division_points():
    from session_py import Polyline
    from session_py import Point
    from session_py import Vector

    poly = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(10.0, 0.0, 0.0),
            Point(10.0, 10.0, 0.0),
            Point(0.0, 10.0, 0.0),
        ]
    )
    polys = [poly]
    dir = Vector(0.0, 0.0, 0.0)
    pts = Polyline.polylabel_circle_division_points(dir, polys, 4, 0.5, 1.0, True)

    MINI_CHECK(len(pts) == 4)

    for p in pts:
        MINI_CHECK(abs(p[2]) < 1e-6)


@MINI_TEST("Polyline", "Boolean Op")
def test_polyline_boolean_op():
    from session_py import Point
    from session_py import Polyline

    sq_a = Polyline(
        [
            Point(-1.0, -1.0, 0.0),
            Point(1.0, -1.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(-1.0, 1.0, 0.0),
        ]
    )
    sq_b = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
        ]
    )
    sq_inside = Polyline(
        [
            Point(-0.5, -0.5, 0.0),
            Point(0.5, -0.5, 0.0),
            Point(0.5, 0.5, 0.0),
            Point(-0.5, 0.5, 0.0),
        ]
    )
    sq_disjoint = Polyline(
        [
            Point(5.0, 5.0, 0.0),
            Point(6.0, 5.0, 0.0),
            Point(6.0, 6.0, 0.0),
            Point(5.0, 6.0, 0.0),
        ]
    )

    isect = Polyline.boolean_op(sq_a, sq_b, 0)
    uni = Polyline.boolean_op(sq_a, sq_b, 1)
    diff = Polyline.boolean_op(sq_a, sq_b, 2)

    MINI_CHECK(len(isect) == 1)
    MINI_CHECK(isect[0].point_count() == 4)
    MINI_CHECK(len(uni) == 1)
    MINI_CHECK(uni[0].point_count() == 8)
    MINI_CHECK(len(diff) == 1)
    MINI_CHECK(diff[0].point_count() == 6)

    isect_in = Polyline.boolean_op(sq_a, sq_inside, 0)
    uni_in = Polyline.boolean_op(sq_a, sq_inside, 1)
    diff_in = Polyline.boolean_op(sq_a, sq_inside, 2)

    MINI_CHECK(len(isect_in) == 1)
    MINI_CHECK(isect_in[0].point_count() == 4)
    MINI_CHECK(len(uni_in) == 1)
    MINI_CHECK(uni_in[0].point_count() == 4)
    MINI_CHECK(len(diff_in) == 1)
    MINI_CHECK(diff_in[0].point_count() == 4)

    isect_dis = Polyline.boolean_op(sq_a, sq_disjoint, 0)
    uni_dis = Polyline.boolean_op(sq_a, sq_disjoint, 1)
    diff_dis = Polyline.boolean_op(sq_a, sq_disjoint, 2)

    MINI_CHECK(len(isect_dis) == 0)
    MINI_CHECK(len(uni_dis) == 2)
    MINI_CHECK(len(diff_dis) == 1)


@MINI_TEST("Polyline", "Boolean Op Plane")
def test_polyline_boolean_op_plane():
    from session_py import Plane
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    origin = Point(0.0, 0.0, 5.0)
    normal = Vector(0.0, 0.0, 1.0)
    plane = Plane.from_point_normal(origin, normal)
    sq_a = Polyline(
        [
            Point(-1.0, -1.0, 5.0),
            Point(1.0, -1.0, 5.0),
            Point(1.0, 1.0, 5.0),
            Point(-1.0, 1.0, 5.0),
            Point(-1.0, -1.0, 5.0),
        ]
    )
    sq_b = Polyline(
        [
            Point(0.0, 0.0, 5.0),
            Point(2.0, 0.0, 5.0),
            Point(2.0, 2.0, 5.0),
            Point(0.0, 2.0, 5.0),
            Point(0.0, 0.0, 5.0),
        ]
    )
    isect = Polyline.boolean_op(sq_a, sq_b, 0, plane)
    uni = Polyline.boolean_op(sq_a, sq_b, 1, plane)
    diff = Polyline.boolean_op(sq_a, sq_b, 2, plane)

    MINI_CHECK(len(isect) == 1)
    MINI_CHECK(len(uni) == 1)
    MINI_CHECK(len(diff) == 1)

    for p in isect[0].get_points():
        MINI_CHECK(TOLERANCE.is_close(p[2], 5.0))

    for p in uni[0].get_points():
        MINI_CHECK(TOLERANCE.is_close(p[2], 5.0))

    for p in diff[0].get_points():
        MINI_CHECK(TOLERANCE.is_close(p[2], 5.0))


@MINI_TEST("Polyline", "Merge Collinear")
def test_polyline_merge_collinear():
    from session_py import Polyline
    from session_py import Point

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 1.0, 0.0),
        ]
    )
    pl.merge_collinear(Tolerance.APPROXIMATION)

    MINI_CHECK(pl.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(1)[0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(2)[1], 1.0))


@MINI_TEST("Polyline", "Simplify Points")
def test_polyline_simplify_points():
    import math
    from session_py import Polyline
    from session_py import Point

    pts = []

    for i in range(100):
        x = float(i)
        y = math.sin(float(i) * 0.1) * 0.001
        z = 0.0
        pts.append(Point(x, y, z))

    result_tight = Polyline.simplify_points(pts, 0.0001)
    result_loose = Polyline.simplify_points(pts, 0.01)
    result_very_loose = Polyline.simplify_points(pts, 1.0)

    MINI_CHECK(len(result_tight) <= len(pts))
    MINI_CHECK(len(result_loose) <= len(result_tight))
    MINI_CHECK(len(result_very_loose) <= len(result_loose))
    MINI_CHECK(result_tight[0][0] == pts[0][0])
    MINI_CHECK(result_tight[-1][0] == pts[-1][0])


@MINI_TEST("Polyline", "Simplify")
def test_polyline_simplify():
    from session_py import Polyline
    from session_py import Point

    pts = []

    for i in range(20):
        x = float(i)
        y = 0.0
        z = 0.0
        pts.append(Point(x, y, z))

    pl = Polyline(pts)
    result = pl.simplify(0.001)

    MINI_CHECK(result.point_count() == 2)
    MINI_CHECK(TOLERANCE.is_close(result.get_point(0)[0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(result.get_point(1)[0], 19.0))


@MINI_TEST("Polyline", "Simplify Collinear")
def test_polyline_simplify_collinear():
    from session_py import Polyline
    from session_py import Point

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(1.0, 0.0, 0.0),
        Point(2.0, 0.0, 0.0),
        Point(3.0, 0.0, 0.0),
        Point(4.0, 0.0, 0.0),
    ]
    result = Polyline.simplify_points(pts, 0.001)

    MINI_CHECK(len(result) == 2)
    MINI_CHECK(TOLERANCE.is_close(result[0][0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(result[-1][0], 4.0))


@MINI_TEST("Polyline", "Simplify Zigzag")
def test_polyline_simplify_zigzag():
    from session_py import Polyline
    from session_py import Point

    pts = []

    for i in range(10):
        x = float(i)
        y = 1.0 if i % 2 == 1 else 0.0
        z = 0.0
        pts.append(Point(x, y, z))

    result_tight = Polyline.simplify_points(pts, 0.1)
    result_loose = Polyline.simplify_points(pts, 2.0)

    MINI_CHECK(len(result_tight) == 10)
    MINI_CHECK(len(result_loose) < len(result_tight))


@MINI_TEST("Polyline", "Simplify Two Points")
def test_polyline_simplify_two_points():
    from session_py import Polyline
    from session_py import Point

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(1.0, 1.0, 1.0),
    ]
    result = Polyline.simplify_points(pts, 0.001)

    MINI_CHECK(len(result) == 2)


@MINI_TEST("Polyline", "Translate")
def test_polyline_translate():
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
        ]
    )
    pl.translate(Vector(5.0, 0.0, 0.0))

    MINI_CHECK(TOLERANCE.is_close(pl.get_point(0)[0], 5.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(2)[0], 6.0))


@MINI_TEST("Polyline", "Extend Edge Equally")
def test_polyline_extend_edge_equally():
    from session_py import Point
    from session_py import Polyline

    pl = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(10.0, 0.0, 0.0),
            Point(10.0, 10.0, 0.0),
            Point(0.0, 10.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    pl.extend_edge_equally(0, 1.0)

    MINI_CHECK(TOLERANCE.is_close(pl.get_point(0)[0], -1.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(1)[0], 11.0))
    MINI_CHECK(TOLERANCE.is_close(pl.get_point(4)[0], -1.0))


@MINI_TEST("Polyline", "Offset Sides")
def test_polyline_offset_sides():
    from session_py import Point
    from session_py import Polyline

    square = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    split = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 1.0, 0.0),
            Point(0.0, 1.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    moved = square.offset_sides([1.0, 0.0, 0.0, 0.0])
    stepped = split.offset_sides([1.0, 2.0, 0.0, 0.0, 0.0])

    MINI_CHECK(moved.point_count() == 5)
    MINI_CHECK(moved.is_closed())
    MINI_CHECK(TOLERANCE.is_close(moved.get_point(0)[1], -1.0))
    MINI_CHECK(TOLERANCE.is_close(moved.get_point(1)[0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(moved.get_point(1)[1], -1.0))
    MINI_CHECK(TOLERANCE.is_close(moved.get_point(2)[1], 2.0))
    MINI_CHECK(TOLERANCE.is_close(stepped.get_point(0)[1], -1.0))
    MINI_CHECK(TOLERANCE.is_close(stepped.get_point(1)[1], -2.0))
    MINI_CHECK(TOLERANCE.is_close(stepped.get_point(2)[1], -2.0))


@MINI_TEST("Polyline", "Offset Sides Degenerate")
def test_polyline_offset_sides_degenerate():
    from session_py import Point
    from session_py import Polyline

    square = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    empty = Polyline().offset_sides([1.0])
    short_distances = square.offset_sides([1.0, 1.0])

    MINI_CHECK(empty.point_count() == 0)
    MINI_CHECK(short_distances.point_count() == 0)


@MINI_TEST("Polyline", "Is Visible Round Trip")
def test_polyline_is_visible_round_trip():
    from session_py import Polyline
    from session_py import Point

    points = [Point(0.0, 0.0, 0.0), Point(1.0, 0.0, 0.0), Point(1.0, 1.0, 0.0)]
    hidden = Polyline(points)

    MINI_CHECK(hidden.is_visible)

    hidden.is_visible = False
    json = Polyline.file_json_loads(hidden.file_json_dumps())
    proto = Polyline.pb_loads(hidden.pb_dumps())

    MINI_CHECK(not json.is_visible)
    MINI_CHECK(not proto.is_visible)


@MINI_TEST("Polyline", "Is Locked Round Trip")
def test_polyline_is_locked_round_trip():
    from session_py import Polyline
    from session_py import Point

    points = [Point(0.0, 0.0, 0.0), Point(1.0, 0.0, 0.0), Point(1.0, 1.0, 0.0)]
    locked = Polyline(points)

    MINI_CHECK(not locked.is_locked)

    locked.is_locked = True
    json = Polyline.file_json_loads(locked.file_json_dumps())
    proto = Polyline.pb_loads(locked.pb_dumps())

    MINI_CHECK(json.is_locked)
    MINI_CHECK(proto.is_locked)


@MINI_TEST("Polyline", "From Planes")
def test_polyline_from_planes():
    from session_py import Plane
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    base = Plane.from_point_normal(Point(0.0, 0.0, 1.0), Vector(0.0, 0.0, 1.0))
    sides = [
        Plane.from_point_normal(Point(0.0, 0.0, 0.0), Vector(-1.0, 0.0, 0.0)),
        Plane.from_point_normal(Point(0.0, 0.0, 0.0), Vector(0.0, -1.0, 0.0)),
        Plane.from_point_normal(Point(2.0, 2.0, 0.0), Vector(1.0, 0.0, 0.0)),
        Plane.from_point_normal(Point(2.0, 2.0, 0.0), Vector(0.0, 1.0, 0.0)),
    ]
    square = Polyline.from_planes(sides, base)
    parallel = False

    try:
        Polyline.from_planes([sides[0], sides[2], sides[1]], base)
    except ValueError:
        parallel = True

    MINI_CHECK(square.point_count() == 5)
    MINI_CHECK(square.is_closed())
    MINI_CHECK(TOLERANCE.is_close(square.get_point(1)[0], 2.0))
    MINI_CHECK(TOLERANCE.is_close(square.get_point(1)[1], 0.0))
    MINI_CHECK(TOLERANCE.is_close(square.get_point(1)[2], 1.0))
    MINI_CHECK(TOLERANCE.is_close(square.get_point(3)[1], 2.0))
    MINI_CHECK(parallel)


@MINI_TEST("Polyline", "Open Points")
def test_polyline_open_points():
    from session_py import Point
    from session_py import Polyline

    square = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    path = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
        ]
    )

    MINI_CHECK(len(square.open_points()) == 4)
    MINI_CHECK(TOLERANCE.is_close(square.open_points()[3][1], 2.0))
    MINI_CHECK(len(path.open_points()) == 3)


@MINI_TEST("Polyline", "Area")
def test_polyline_area():
    from session_py import Point
    from session_py import Polyline

    square = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 0.0, 0.0),
            Point(2.0, 2.0, 0.0),
            Point(0.0, 2.0, 0.0),
            Point(0.0, 0.0, 0.0),
        ]
    )
    standing = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(4.0, 0.0, 0.0),
            Point(0.0, 0.0, 3.0),
        ]
    )
    segment = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(4.0, 0.0, 0.0),
        ]
    )

    MINI_CHECK(TOLERANCE.is_close(square.area(), 4.0))
    MINI_CHECK(TOLERANCE.is_close(standing.area(), 6.0))
    MINI_CHECK(segment.area() == 0.0)


@MINI_TEST("Polyline", "Area Centroid")
def test_polyline_area_centroid():
    from session_py import Point
    from session_py import Polyline

    shape = Polyline(
        [
            Point(0.0, 0.0, 2.0),
            Point(4.0, 0.0, 2.0),
            Point(4.0, 1.0, 2.0),
            Point(1.0, 1.0, 2.0),
            Point(1.0, 3.0, 2.0),
            Point(0.0, 3.0, 2.0),
            Point(0.0, 0.0, 2.0),
        ]
    )
    centroid = shape.area_centroid()
    reversed = shape.reversed().area_centroid()

    MINI_CHECK(TOLERANCE.is_close(centroid[0], 1.5))
    MINI_CHECK(TOLERANCE.is_close(centroid[1], 1.0))
    MINI_CHECK(TOLERANCE.is_close(centroid[2], 2.0))
    MINI_CHECK(TOLERANCE.is_close(reversed[0], 1.5))
    MINI_CHECK(TOLERANCE.is_close(reversed[1], 1.0))


@MINI_TEST("Polyline", "Offset Toward")
def test_polyline_offset_toward():
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    arch = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(5.0, 0.0, 5.0),
            Point(10.0, 0.0, 0.0),
        ]
    )
    offset = arch.offset_toward(1.0, Vector(0.0, 0.0, 1.0))
    same = arch.offset_toward(0.0, Vector(0.0, 0.0, 1.0))

    MINI_CHECK(offset.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(offset.get_point(0)[0], -0.5 * math.sqrt(2.0)))
    MINI_CHECK(TOLERANCE.is_close(offset.get_point(0)[2], 0.5 * math.sqrt(2.0)))
    MINI_CHECK(TOLERANCE.is_close(offset.get_point(1)[0], 5.0))
    MINI_CHECK(TOLERANCE.is_close(offset.get_point(1)[2], 5.0 + math.sqrt(2.0)))
    MINI_CHECK(TOLERANCE.is_close(offset.get_point(2)[0], 10.0 + 0.5 * math.sqrt(2.0)))
    MINI_CHECK(TOLERANCE.is_close(same.get_point(1)[2], 5.0))


@MINI_TEST("Polyline", "Extended")
def test_polyline_extended():
    from session_py import Point
    from session_py import Polyline

    path = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(1.0, 0.0, 0.0),
            Point(1.0, 1.0, 0.0),
        ]
    )
    single = Polyline([Point(1.0, 2.0, 3.0)])
    longer = path.extended(2.0, 3.0)
    shorter = path.extended(-0.5, 0.0)

    MINI_CHECK(longer.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(longer.get_point(0)[0], -2.0))
    MINI_CHECK(TOLERANCE.is_close(longer.get_point(1)[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(longer.get_point(2)[1], 4.0))
    MINI_CHECK(TOLERANCE.is_close(shorter.get_point(0)[0], 0.5))
    MINI_CHECK(TOLERANCE.is_close(shorter.get_point(2)[1], 1.0))
    MINI_CHECK(single.extended(2.0, 3.0).point_count() == 1)


@MINI_TEST("Polyline", "Trimmed")
def test_polyline_trimmed():
    from session_py import Plane
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    path = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(10.0, 0.0, 0.0),
            Point(20.0, 0.0, 0.0),
        ]
    )
    plane0 = Plane.from_point_normal(Point(5.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    plane1 = Plane.from_point_normal(Point(15.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    beyond0 = Plane.from_point_normal(Point(-5.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    beyond1 = Plane.from_point_normal(Point(25.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    inside = path.trimmed(plane0, plane1, 100.0)
    outside = path.trimmed(beyond0, beyond1, 100.0)

    MINI_CHECK(inside.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(inside.get_point(0)[0], 5.0))
    MINI_CHECK(TOLERANCE.is_close(inside.get_point(2)[0], 15.0))
    MINI_CHECK(outside.point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(outside.get_point(0)[0], -5.0))
    MINI_CHECK(TOLERANCE.is_close(outside.get_point(2)[0], 25.0))


@MINI_TEST("Polyline", "Trimmed Alike")
def test_polyline_trimmed_alike():
    from session_py import Plane
    from session_py import Point
    from session_py import Polyline
    from session_py import Vector

    a = Polyline(
        [
            Point(0.0, 0.0, 0.0),
            Point(10.0, 0.0, 0.0),
            Point(20.0, 0.0, 0.0),
        ]
    )
    b = Polyline(
        [
            Point(0.0, 5.0, 0.0),
            Point(10.0, 5.0, 0.0),
            Point(20.0, 5.0, 0.0),
        ]
    )
    c = Polyline(
        [
            Point(0.0, 9.0, 0.0),
            Point(20.0, 9.0, 0.0),
        ]
    )
    plane0 = Plane.from_point_normal(Point(5.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    plane1 = Plane.from_point_normal(Point(15.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    missing = Plane.from_point_normal(Point(500.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0))
    trimmed = Polyline.trimmed_alike([a, b], plane1, plane0, 100.0)
    mixed = False
    missed = False

    try:
        Polyline.trimmed_alike([a, c], plane0, plane1, 100.0)
    except ValueError:
        mixed = True

    try:
        Polyline.trimmed_alike([a, b], plane0, missing, 100.0)
    except ValueError:
        missed = True

    MINI_CHECK(len(trimmed) == 2)
    MINI_CHECK(trimmed[1].point_count() == 3)
    MINI_CHECK(TOLERANCE.is_close(trimmed[1].get_point(0)[0], 5.0))
    MINI_CHECK(TOLERANCE.is_close(trimmed[1].get_point(0)[1], 5.0))
    MINI_CHECK(TOLERANCE.is_close(trimmed[1].get_point(2)[0], 15.0))
    MINI_CHECK(mixed)
    MINI_CHECK(missed)


if __name__ == "__main__":
    run_all("python")
