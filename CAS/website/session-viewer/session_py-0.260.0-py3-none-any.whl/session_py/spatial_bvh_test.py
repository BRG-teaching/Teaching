from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all
from .tolerance import TOLERANCE


@MINI_TEST("SpatialBVH", "Constructor")
def test_bvh_constructor():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(2.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(20.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    n = bvh.nearest_neighbors(0, boxes, 1.5)

    MINI_CHECK(len(n) == 1)
    MINI_CHECK(n[0] == 1)


@MINI_TEST("SpatialBVH", "Expand Bits")
def test_bvh_expand_bits():
    from session_py.spatial_bvh import expand_bits

    MINI_CHECK(expand_bits(0) == 0)
    MINI_CHECK(expand_bits(1) == 1)
    MINI_CHECK(expand_bits(2) == 8)
    MINI_CHECK(expand_bits(3) == 9)

    result = expand_bits(1023)

    MINI_CHECK(result > 0)


@MINI_TEST("SpatialBVH", "Morton Code Origin")
def test_bvh_morton_code_origin():
    from session_py.spatial_bvh import calculate_morton_code

    code = calculate_morton_code(0.0, 0.0, 0.0, 100.0)

    MINI_CHECK(code < (1 << 30))


@MINI_TEST("SpatialBVH", "Morton Code Corners")
def test_bvh_morton_code_corners():
    from session_py.spatial_bvh import calculate_morton_code

    code_min = calculate_morton_code(-50.0, -50.0, -50.0, 100.0)

    MINI_CHECK(code_min == 0)

    code_max = calculate_morton_code(50.0, 50.0, 50.0, 100.0)

    MINI_CHECK(code_max == 0x3FFFFFFF)


@MINI_TEST("SpatialBVH", "Morton Code Spatial Locality")
def test_bvh_morton_code_spatial_locality():
    from session_py.spatial_bvh import calculate_morton_code

    code1 = calculate_morton_code(10.0, 10.0, 10.0)
    code2 = calculate_morton_code(10.1, 10.1, 10.1)
    code3 = calculate_morton_code(-40.0, -40.0, -40.0)
    diff_nearby = abs(code1 - code2)
    diff_far = abs(code1 - code3)

    MINI_CHECK(diff_nearby < diff_far)


@MINI_TEST("SpatialBVH", "Node Creation")
def test_bvh_node_creation():
    from session_py.spatial_bvh import Node

    node = Node()

    MINI_CHECK(node.left == -1)
    MINI_CHECK(node.right == -1)
    MINI_CHECK(node.object_id == -1)
    MINI_CHECK(not node.is_leaf())


@MINI_TEST("SpatialBVH", "Node Leaf")
def test_bvh_node_leaf():
    from session_py.spatial_bvh import Node

    node = Node()

    MINI_CHECK(not node.is_leaf())

    node.object_id = 5

    MINI_CHECK(node.is_leaf())


@MINI_TEST("SpatialBVH", "Creation")
def test_bvh_creation():
    from session_py import SpatialBVH

    bvh = SpatialBVH(100.0)

    MINI_CHECK(len(bvh.guid) > 0)
    MINI_CHECK(bvh.name == "my_bvh")
    MINI_CHECK(bvh.empty())
    MINI_CHECK(TOLERANCE.is_close(bvh.world_size, 100.0))


@MINI_TEST("SpatialBVH", "Build Empty")
def test_bvh_build_empty():
    from session_py import SpatialBVH

    boxes = []
    bvh = SpatialBVH.from_boxes(boxes, 100.0)

    MINI_CHECK(bvh.empty())


@MINI_TEST("SpatialBVH", "Build Single")
def test_bvh_build_single():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0))]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)

    MINI_CHECK(bvh.size() == 1)
    MINI_CHECK(bvh.nodes[0].is_leaf())
    MINI_CHECK(bvh.nodes[0].object_id == 0)


@MINI_TEST("SpatialBVH", "Build Multiple")
def test_bvh_build_multiple():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(-10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.0, 10.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)

    MINI_CHECK(bvh.size() == 5)
    MINI_CHECK(not bvh.nodes[0].is_leaf())
    MINI_CHECK(bvh.nodes[0].left != -1)
    MINI_CHECK(bvh.nodes[0].right != -1)


@MINI_TEST("SpatialBVH", "Aabb Intersect")
def test_bvh_aabb_intersect():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    bvh = SpatialBVH(100.0)
    bbox1 = OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0))
    bbox2 = OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0))
    bbox3 = OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0))

    MINI_CHECK(bvh.aabb_intersect(bbox1, bbox2))
    MINI_CHECK(not bvh.aabb_intersect(bbox1, bbox3))
    MINI_CHECK(
        bvh.aabb_intersect(
            AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), AABB(1.5, 0.0, 0.0, 1.0, 1.0, 1.0)
        )
    )


@MINI_TEST("SpatialBVH", "Check All Collisions")
def test_bvh_check_all_collisions():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    result = bvh.check_all_collisions(boxes)
    collisions = result[0]
    colliding_indices = result[1]

    MINI_CHECK(len(collisions) == 1)
    MINI_CHECK(collisions[0][0] == 0)
    MINI_CHECK(collisions[0][1] == 1)
    MINI_CHECK(len(colliding_indices) == 2)
    MINI_CHECK(colliding_indices[0] == 0)
    MINI_CHECK(colliding_indices[1] == 1)
    MINI_CHECK(result[2] > 0)


@MINI_TEST("SpatialBVH", "Nearest Neighbors")
def test_bvh_nearest_neighbors():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    n0 = bvh.nearest_neighbors(0, boxes, 1.2)

    MINI_CHECK(len(n0) == 1)
    MINI_CHECK(n0[0] == 1)

    n2 = bvh.nearest_neighbors(2, boxes, 1.2)

    MINI_CHECK(len(n2) == 0)

    n2_wide = bvh.nearest_neighbors(2, boxes, 10.0)

    MINI_CHECK(len(n2_wide) == 2)


@MINI_TEST("SpatialBVH", "Merge Aabb")
def test_bvh_merge_aabb():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    bvh = SpatialBVH(100.0)
    bbox1 = OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0))
    bbox2 = OBB.from_aabb(AABB(5.0, 0.0, 0.0, 1.0, 1.0, 1.0))
    merged = bvh.merge_aabb(bbox1, bbox2)

    MINI_CHECK(TOLERANCE.is_close(merged.center[0], 2.5))
    MINI_CHECK(TOLERANCE.is_close(merged.half_size[0], 3.5))


@MINI_TEST("SpatialBVH", "Fixed 100 Boxes")
def test_bvh_fixed_100_boxes():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB
    from session_py import Point

    corners = [
        [-53.1254, -0.98185, 20.5516, -46.8089, 5.89927, 26.5331],
        [44.4446, -1.5359, -1.49382, 50.7301, 3.99953, 7.58362],
        [36.9359, -7.76782, -28.7694, 43.173, -1.82645, -22.1528],
        [-44.2654, 26.3949, 0.745263, -35.0431, 35.0799, 6.13693],
        [0.239448, -40.5791, 32.6275, 7.56243, -33.2192, 39.8776],
        [-31.6363, -53.5568, -52.162, -21.6687, -43.9796, -43.2328],
        [3.72143, 23.485, 9.18924, 10.4425, 30.3631, 15.5248],
        [-17.4583, 10.2729, -16.5162, -12.1943, 17.9162, -10.7277],
        [-7.27998, -22.0384, -34.5872, -1.95631, -12.1058, -26.8567],
        [-45.341, 46.3634, -10.4862, -36.8332, 52.2971, -2.76774],
        [46.0445, -34.6013, 14.0587, 53.0414, -27.4064, 22.7938],
        [-34.9367, 28.5039, 27.7749, -29.4494, 33.6524, 33.4448],
        [9.97675, -15.7696, -27.8198, 17.5104, -8.16385, -22.3021],
        [45.1965, -19.307, 22.0449, 51.5233, -10.9748, 31.6205],
        [-7.03031, -10.8607, 38.8429, 0.306212, -0.974567, 45.443],
        [25.5248, 31.9848, 20.436, 33.3122, 41.1186, 28.0921],
        [-22.8772, -19.5722, -22.9988, -15.6443, -11.7384, -14.7361],
        [-46.2318, -5.27625, -7.84674, -41.1843, 3.22896, -0.905452],
        [-8.8814, 40.3852, -41.0122, -1.73994, 46.8478, -33.9574],
        [-30.4719, -15.9782, 17.3287, -20.7941, -10.8891, 24.7185],
        [28.6586, 0.44821, -41.9327, 35.6602, 6.09223, -32.8706],
        [-14.173, -45.5086, 6.29666, -7.48969, -39.2406, 13.229],
        [-21.8039, 6.68129, -32.5692, -15.3816, 16.6269, -26.5873],
        [13.3659, -1.97758, 25.4002, 19.0017, 4.81311, 31.5121],
        [-24.433, -37.1532, 41.849, -15.8042, -29.2066, 49.4371],
        [-4.54629, -16.9216, -24.2439, 2.40272, -9.87919, -17.0974],
        [-22.1316, -18.2577, -41.6624, -13.4863, -11.2109, -36.6118],
        [-19.5562, -1.13082, -35.7364, -10.2048, 8.43363, -25.912],
        [26.4514, -31.3635, -3.53901, 32.4376, -22.007, 5.52268],
        [44.2805, -20.3072, 10.0337, 52.6535, -10.845, 15.6482],
        [15.1756, 46.2379, 44.9662, 20.8272, 53.0835, 50.1683],
        [1.39766, -37.0106, -2.59787, 7.17823, -28.0455, 3.65286],
        [-31.882, -21.1354, 20.6053, -24.8106, -11.3482, 28.4804],
        [-8.54435, 10.0787, 41.0063, -1.08096, 17.3793, 46.4334],
        [21.317, -38.2325, 3.71512, 29.3482, -31.5114, 10.6611],
        [-31.9136, 27.8033, -4.48008, -23.6666, 35.3487, 0.804813],
        [8.52067, 14.4157, -37.4169, 17.5301, 20.4823, -32.1696],
        [-7.88355, 21.208, 42.2586, -0.205483, 26.4206, 50.4889],
        [-15.322, -4.75221, -17.9083, -8.4181, 4.47693, -8.67731],
        [37.1268, 2.17059, -48.8049, 45.7917, 8.4744, -40.7264],
        [-52.3809, -6.49423, 8.92399, -42.9845, 0.188961, 18.343],
        [41.5732, -7.42366, -4.54156, 51.0067, -2.29871, 0.643029],
        [-5.78252, 0.645065, -13.4131, 1.93946, 8.96885, -5.49512],
        [7.58556, -41.9641, 23.8841, 16.6142, -32.1089, 31.049],
        [-46.102, -9.30967, 44.8527, -36.2572, -2.2869, 51.5056],
        [45.8031, 27.0115, -17.4386, 52.3382, 32.367, -7.79126],
        [8.21008, 39.3673, 20.643, 17.4628, 45.1004, 28.0194],
        [-47.9111, -24.7374, -29.2773, -40.7686, -16.0819, -20.6671],
        [-29.8193, -10.8358, 24.5871, -21.6958, -3.36907, 33.5925],
        [26.9713, -26.2038, -31.9261, 35.2619, -20.0422, -25.0245],
        [-29.7903, 8.92347, -40.826, -21.7701, 15.776, -35.2006],
        [-1.39845, -13.7028, -13.4383, 8.26331, -8.56298, -7.95241],
        [-27.3862, 17.0337, 30.1216, -19.7585, 22.0732, 39.076],
        [-15.102, -39.6467, -37.4648, -8.16651, -34.4574, -31.1032],
        [14.1428, -34.4961, -47.6358, 22.6478, -25.6985, -42.1577],
        [32.7187, -0.0187469, -2.54834, 41.5605, 9.91946, 3.89622],
        [18.869, -24.3319, -0.588445, 27.1926, -18.2572, 6.42131],
        [4.33372, 6.78191, -26.4923, 12.7318, 13.5283, -19.058],
        [-3.88995, -20.8689, 18.4182, 4.99471, -11.484, 25.6025],
        [-10.2896, -22.7252, -40.4815, -3.08794, -13.9661, -30.6919],
        [30.2898, 7.94805, -2.19314, 35.3154, 17.6367, 5.55489],
        [-33.8415, 21.4915, -16.5747, -26.6066, 27.2365, -10.8669],
        [-22.4042, 38.4298, 21.7984, -13.9447, 47.0733, 28.4925],
        [-6.87762, 2.83366, 10.2831, -0.784998, 11.5311, 18.5943],
        [-34.4398, -36.757, 27.0559, -27.6572, -27.51, 36.7491],
        [35.4006, -17.8502, -21.4524, 41.7323, -10.0449, -12.5719],
        [28.1073, 31.8896, -16.4485, 33.4307, 37.9012, -9.80763],
        [13.5936, 25.9705, 8.3269, 22.4543, 32.3162, 16.4279],
        [28.2281, -51.9913, -14.7078, 35.0256, -42.5897, -6.77297],
        [-27.4511, -21.3243, 42.9791, -18.7936, -14.3339, 50.3538],
        [-42.0679, -47.6033, -33.2027, -32.8703, -38.8405, -26.6373],
        [-52.2085, -52.5573, -33.0963, -45.8755, -44.5128, -23.5496],
        [-11.2779, -9.99167, 24.9689, -5.92983, -0.191222, 31.1336],
        [33.121, 2.70727, -33.8816, 38.3024, 10.367, -26.2656],
        [-5.30061, -39.8595, 33.6105, 4.23731, -31.0826, 42.5769],
        [-0.704829, -26.0593, -30.9797, 4.64116, -16.105, -24.9783],
        [37.3045, 34.9896, 2.13491, 46.4151, 40.7296, 10.6969],
        [-27.6823, 41.9125, -36.4809, -17.7935, 47.2728, -26.7252],
        [34.666, 27.0233, 23.9605, 44.5308, 33.3, 30.9151],
        [-37.3694, -40.3928, -6.27422, -28.0124, -31.5777, -0.670845],
        [-34.1601, 33.6584, -28.8227, -27.286, 42.4497, -22.2408],
        [-30.329, -4.34317, -43.1085, -23.815, 5.64745, -35.7657],
        [-31.824, 8.78623, 25.1597, -24.1868, 17.2063, 31.7098],
        [8.9247, -12.5921, 35.2262, 16.9325, -5.38381, 44.3014],
        [-11.6258, 44.3936, -29.2716, -3.07673, 49.3977, -20.2529],
        [-27.9412, 32.9874, -20.8262, -22.5216, 39.9326, -12.0579],
        [39.7539, -22.0106, 31.131, 46.0297, -14.2677, 40.1578],
        [-10.4385, 20.3835, 5.16852, -5.23064, 28.6092, 14.2703],
        [19.9106, -32.364, 8.76233, 25.9003, -24.1348, 16.1047],
        [-0.62887, 18.0559, 41.0991, 5.37937, 23.5869, 49.7166],
        [20.6713, -12.7322, -19.7395, 28.0693, -3.71518, -11.0217],
        [42.2797, -30.3842, 8.4357, 51.5113, -24.6986, 15.3918],
        [-18.9658, -26.1333, -9.25188, -12.9283, -17.8373, -3.68668],
        [32.8414, -44.7499, -3.96548, 41.3729, -35.5501, 1.88547],
        [-12.0107, -43.9043, 15.2958, -6.24849, -38.452, 21.6608],
        [-28.9449, 35.0651, -45.8908, -23.5524, 42.0763, -39.3406],
        [25.2023, -12.4615, 8.84863, 30.8803, -6.57652, 18.4333],
        [31.7285, 31.0991, -7.73725, 39.8767, 38.2288, 0.932107],
        [-35.1346, -8.00369, 14.4611, -27.1614, -1.58541, 21.4893],
        [13.9228, -49.9973, -2.77406, 23.104, -41.5596, 4.89623],
    ]
    boxes = []

    for corner in corners:
        lo = Point(corner[0], corner[1], corner[2])
        hi = Point(corner[3], corner[4], corner[5])
        boxes.append(OBB.from_aabb(AABB.from_points([lo, hi])))

    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    pairs = bvh.check_all_collisions(boxes)[0]

    pairs.sort()

    MINI_CHECK(len(boxes) == 100)
    MINI_CHECK(len(pairs) == 13)
    MINI_CHECK((4, 74) in pairs)

    for pair in pairs:
        MINI_CHECK(pair[0] < 100)
        MINI_CHECK(pair[1] < 100)
        MINI_CHECK(pair[0] < pair[1])


@MINI_TEST("SpatialBVH", "Query Aabb")
def test_bvh_query_aabb():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(5.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.0, 5.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    hits = bvh.query_aabb(OBB.from_aabb(AABB(0.0, 0.0, 0.0, 0.5, 0.5, 0.5)))

    MINI_CHECK(0 in hits)
    MINI_CHECK(1 not in hits)
    MINI_CHECK(2 not in hits)

    hits_all = bvh.query_aabb(AABB(2.5, 2.5, 0.0, 5.0, 5.0, 2.0))

    MINI_CHECK(len(hits_all) == 3)


@MINI_TEST("SpatialBVH", "Build From Boxes")
def test_bvh_build_from_boxes():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH()
    bvh.build_from_boxes(boxes, 100.0)
    pairs = bvh.check_all_collisions(boxes)[0]

    MINI_CHECK(TOLERANCE.is_close(bvh.world_size, 100.0))
    MINI_CHECK(len(pairs) == 1)
    MINI_CHECK(pairs[0] == (0, 1))


@MINI_TEST("SpatialBVH", "Build From Aabbs")
def test_bvh_build_from_aabbs():
    from session_py import SpatialBVH
    from session_py import AABB

    aabbs = [
        AABB(0.0, 0.0, 0.0, 2.0, 2.0, 2.0),
        AABB(3.0, 0.0, 0.0, 2.0, 2.0, 2.0),
        AABB(50.0, 0.0, 0.0, 2.0, 2.0, 2.0),
    ]
    bvh = SpatialBVH()
    bvh.build_from_aabbs(aabbs, 100.0)
    hits = bvh.query_aabb(AABB(0.0, 0.0, 0.0, 2.0, 2.0, 2.0))

    MINI_CHECK(len(hits) == 2)
    MINI_CHECK(0 in hits)
    MINI_CHECK(1 in hits)


@MINI_TEST("SpatialBVH", "Build With Guids")
def test_bvh_build_with_guids():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes_with_guids = [
        (OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)), "a"),
        (OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0)), "b"),
        (OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)), "c"),
    ]
    bvh = SpatialBVH()
    bvh.build_with_guids(boxes_with_guids)

    MINI_CHECK(len(bvh.object_guids) == 3)
    MINI_CHECK(bvh.object_guids[0] == "a")
    MINI_CHECK(TOLERANCE.is_close(bvh.world_size, 24.2))


@MINI_TEST("SpatialBVH", "Check All Collisions Guids")
def test_bvh_check_all_collisions_guids():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    boxes_with_guids = [
        (boxes[0], "a"),
        (boxes[1], "b"),
        (boxes[2], "c"),
    ]
    bvh = SpatialBVH()
    bvh.build_with_guids(boxes_with_guids)
    guid_pairs = bvh.check_all_collisions_guids(boxes)

    MINI_CHECK(len(guid_pairs) == 1)
    MINI_CHECK(guid_pairs[0][0] == "a")
    MINI_CHECK(guid_pairs[0][1] == "b")


@MINI_TEST("SpatialBVH", "Find Collisions")
def test_bvh_find_collisions():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.5, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(10.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    found0 = bvh.find_collisions(0, boxes[0], boxes)
    found2 = bvh.find_collisions(2, boxes[2], boxes)

    MINI_CHECK(found0[0] == [1])
    MINI_CHECK(found0[1] > 0)
    MINI_CHECK(len(found2[0]) == 0)


@MINI_TEST("SpatialBVH", "Ray Cast")
def test_bvh_ray_cast():
    from session_py import SpatialBVH
    from session_py import AABB
    from session_py import OBB
    from session_py import Point
    from session_py import Vector

    boxes = [
        OBB.from_aabb(AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(5.0, 0.0, 0.0, 1.0, 1.0, 1.0)),
        OBB.from_aabb(AABB(0.0, 5.0, 0.0, 1.0, 1.0, 1.0)),
    ]
    bvh = SpatialBVH.from_boxes(boxes, 100.0)
    hits = []
    hit = bvh.ray_cast(Point(-10.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0), hits)

    MINI_CHECK(hit)
    MINI_CHECK(len(hits) == 2)
    MINI_CHECK(hits[0] == 0)
    MINI_CHECK(hits[1] == 1)

    miss = bvh.ray_cast(Point(-10.0, 20.0, 0.0), Vector(1.0, 0.0, 0.0), hits)

    MINI_CHECK(not miss)
    MINI_CHECK(len(hits) == 0)


if __name__ == "__main__":
    run_all(language="python")
