from __future__ import annotations
from typing import TYPE_CHECKING
import copy
import heapq
import json
import math
import uuid
from .color import Color
from .plane import Plane
from .point import Point
from .tolerance import Tolerance
from .vector import Vector

if TYPE_CHECKING:
    from pathlib import Path
    from .line import Line
    from .proto import polyline_pb2
    from .xform import Xform


# ═══════════════════════════════════════════════════════════════════════════
# 2D helpers
# ═══════════════════════════════════════════════════════════════════════════
def _ccw_2d(ax: float, ay: float, bx: float, by: float, px: float, py: float) -> float:
    """Return the cross product sign of (b - a) x (p - a)."""
    return (bx - ax) * (py - ay) - (by - ay) * (px - ax)


def _seg_dist_sq(
    px: float, py: float, ax: float, ay: float, bx: float, by: float
) -> float:
    """Return the squared distance from (px, py) to the segment (a, b)."""

    x = ax
    y = ay
    dx = bx - x
    dy = by - y

    if dx != 0.0 or dy != 0.0:
        t = ((px - x) * dx + (py - y) * dy) / (dx * dx + dy * dy)

        if t > 1.0:
            x = bx
            y = by
        elif t > 0.0:
            x += dx * t
            y += dy * t

    dx = px - x
    dy = py - y

    return dx * dx + dy * dy


def _point_to_polygon_dist(
    px: float, py: float, polygon: list[list[tuple[float, float]]]
) -> float:
    """Return the signed distance to the polygon rings, positive inside."""

    inside = False
    min_dist_sq = float("inf")

    for ring in polygon:
        length = len(ring)
        j = length - 1

        for i in range(length):
            ax = ring[i][0]
            ay = ring[i][1]
            bx = ring[j][0]
            by = ring[j][1]

            if (ay > py) != (by > py) and px < (bx - ax) * (py - ay) / (by - ay) + ax:
                inside = not inside

            min_dist_sq = min(min_dist_sq, _seg_dist_sq(px, py, ax, ay, bx, by))
            j = i

    return (1.0 if inside else -1.0) * math.sqrt(min_dist_sq)


class _PCell:
    """Quadtree cell of the polylabel search: center, half size, distance and its upper bound."""

    def __init__(
        self, cx: float, cy: float, h: float, polygon: list[list[tuple[float, float]]]
    ):
        """Construct the cell at (cx, cy) with half size h against polygon."""

        self.cx = cx  # Center x.
        self.cy = cy  # Center y.
        self.h = h  # Half size.
        self.d = _point_to_polygon_dist(
            cx, cy, polygon
        )  # Signed distance from the center to the polygon.
        self.mx = self.d + h * math.sqrt(
            2.0
        )  # Upper bound of the distance inside the cell.

    def __lt__(self, o: _PCell) -> bool:
        """Order by the upper bound so the heap pops the most promising cell."""
        return self.mx > o.mx


def _centroid_cell(polygon: list[list[tuple[float, float]]]) -> _PCell:
    """Return the cell at the centroid of the outer ring."""

    area = 0.0
    cx = 0.0
    cy = 0.0
    ring = polygon[0]
    length = len(ring)
    j = length - 1

    for i in range(length):
        ax = ring[i][0]
        ay = ring[i][1]
        bx = ring[j][0]
        by = ring[j][1]
        f = ax * by - bx * ay
        cx += (ax + bx) * f
        cy += (ay + by) * f
        area += f * 3.0
        j = i

    if area == 0.0:
        return _PCell(ring[0][0], ring[0][1], 0.0, polygon)

    return _PCell(cx / area, cy / area, 0.0, polygon)


def _mapbox_polylabel(
    polygon: list[list[tuple[float, float]]], precision: float
) -> tuple[float, float, float]:
    """Return the center and radius of the largest inscribed circle in 2D (Mapbox polylabel)."""

    min_x = float("inf")
    min_y = float("inf")
    max_x = float("-inf")
    max_y = float("-inf")

    for p in polygon[0]:
        min_x = min(min_x, p[0])
        max_x = max(max_x, p[0])
        min_y = min(min_y, p[1])
        max_y = max(max_y, p[1])

    size_x = max_x - min_x
    size_y = max_y - min_y
    cell_size = min(size_x, size_y)
    h = cell_size / 2.0

    if cell_size == 0.0:
        return (min_x, min_y, 0.0)

    queue = []
    x = min_x

    while x < max_x:
        y = min_y

        while y < max_y:
            heapq.heappush(queue, _PCell(x + h, y + h, h, polygon))
            y += cell_size

        x += cell_size

    best = _centroid_cell(polygon)
    bbox_cell = _PCell(min_x + size_x / 2.0, min_y + size_y / 2.0, 0.0, polygon)

    if bbox_cell.d > best.d:
        best = bbox_cell

    max_iter = 1000000

    for _ in range(max_iter):
        if not queue:
            break

        cell = heapq.heappop(queue)

        if cell.d > best.d:
            best = cell

        if cell.mx - best.d <= precision:
            continue

        nh = cell.h / 2.0
        heapq.heappush(queue, _PCell(cell.cx - nh, cell.cy - nh, nh, polygon))
        heapq.heappush(queue, _PCell(cell.cx + nh, cell.cy - nh, nh, polygon))
        heapq.heappush(queue, _PCell(cell.cx - nh, cell.cy + nh, nh, polygon))
        heapq.heappush(queue, _PCell(cell.cx + nh, cell.cy + nh, nh, polygon))

    return (best.cx, best.cy, best.d)


class Polyline:
    """A polyline stored as flat coordinates [x0, y0, z0, x1, y1, z1, ...] with a lazily computed plane."""

    # ═══════════════════════════════════════════════════════════════════════════
    # Constructors
    # ═══════════════════════════════════════════════════════════════════════════
    def __init__(self, points: list[Point] | None = None):
        """Construct from points."""

        self._guid = None  # Lazily minted GUID.
        self._plane_dirty = True  # True until get_plane recomputes.
        self.name = "my_polyline"  # Polyline name.
        self.is_visible = True  # Whether a viewer draws it.
        self.is_locked = False  # Whether a viewer keeps it from moving.
        self.coords: list[float] = []  # Flat [x, y, z, ...].
        self.plane = Plane()  # Lazily computed plane, see get_plane.
        self.width = 1.0  # Display width.
        self.dash = []  # Dash pattern lengths.
        self.linecolor = Color.black()  # Display color.

        if points is not None:
            for p in points:
                self.coords.extend([p[0], p[1], p[2]])

    def __deepcopy__(self, memo):
        """Copy with a new guid and the same data."""

        result = Polyline()
        result._plane_dirty = self._plane_dirty
        result.name = self.name
        result.is_visible = self.is_visible
        result.is_locked = self.is_locked
        result.coords = list(self.coords)
        result.plane = copy.deepcopy(self.plane, memo)
        result.width = self.width
        result.dash = list(self.dash)
        result.linecolor = copy.deepcopy(self.linecolor, memo)
        memo[id(self)] = result

        return result

    def duplicate(self) -> Polyline:
        """Copy with a new guid and the same data."""
        return copy.deepcopy(self)

    # ═══════════════════════════════════════════════════════════════════════════
    # Static constructors
    # ═══════════════════════════════════════════════════════════════════════════
    @staticmethod
    def from_coords(coords: list[float]) -> Polyline:
        """Construct from flat [x, y, z, ...] coordinates."""

        polyline = Polyline()
        polyline.coords = list(coords)
        polyline._recompute_plane_if_needed()

        return polyline

    @staticmethod
    def from_sides(sides: int, radius: float = 1.0, close: bool = False) -> Polyline:
        """Construct a regular polygon of sides around the origin in the XY plane."""

        points = []

        for i in range(sides):
            angle = 2.0 * Tolerance.PI * i / sides
            points.append(
                Point(radius * math.cos(angle), radius * math.sin(angle), 0.0)
            )

        if close:
            points.append(points[0])

        return Polyline(points)

    @staticmethod
    def rectangle(
        origin: Point,
        x_axis: Vector,
        y_axis: Vector,
        width: float,
        height: float,
        close: bool = True,
    ) -> Polyline:
        """Construct a rectangle with its corner at origin, sides along x_axis and y_axis."""

        plane = Plane(origin, x_axis, y_axis)
        o = plane.origin
        x = plane.x_axis * width
        y = plane.y_axis * height
        points = [o, o + x, o + x + y, o + y]

        if close:
            points.append(points[0])

        return Polyline(points)

    @staticmethod
    def quadratic_points(
        p0: Point, p1: Point, p2: Point, divisions: int = 7
    ) -> Polyline:
        """Construct the quadratic Bezier through p0, p1, p2 sampled at divisions points."""

        n = max(divisions, 2)
        d = float(n - 1)
        points = []

        for k in range(n):
            t = k / d
            s = 1.0 - t
            s2 = s * s
            ts = 2.0 * s * t
            t2 = t * t
            points.append(
                Point(
                    s2 * p0[0] + ts * p1[0] + t2 * p2[0],
                    s2 * p0[1] + ts * p1[1] + t2 * p2[1],
                    s2 * p0[2] + ts * p1[2] + t2 * p2[2],
                )
            )

        return Polyline(points)

    @staticmethod
    def from_planes(sides: list[Plane], base: Plane) -> Polyline:
        """Construct the closed polygon whose corner i is where sides i and i + 1 meet base; raises ValueError when three of them share no point."""

        from .intersection import plane_plane_plane

        n = len(sides)
        points = []

        for i in range(n):
            corner = plane_plane_plane(sides[i], sides[(i + 1) % n], base)

            if corner is None:
                raise ValueError("from_planes: three planes share no point")

            points.append(corner)

        return Polyline(points).closed() if points else Polyline()

    # ═══════════════════════════════════════════════════════════════════════════
    # Accessors
    # ═══════════════════════════════════════════════════════════════════════════
    def has_guid(self) -> bool:
        """Return whether the lazy guid has been created."""
        return self._guid is not None

    @property
    def guid(self) -> str:
        """Return the guid, creating it on first access."""

        if self._guid is None:
            self._guid = str(uuid.uuid4())

        return self._guid

    @guid.setter
    def guid(self, value: str) -> None:
        """Set the guid."""
        self._guid = value

    def refresh_guid(self) -> None:
        """Clear the guid so a fresh one mints lazily on the next read."""
        self._guid = None

    def point_count(self) -> int:
        """Return the number of points."""
        return len(self.coords) // 3

    def __len__(self) -> int:
        """Return the number of points."""
        return self.point_count()

    def is_empty(self) -> bool:
        """Return whether the polyline has no points."""
        return len(self.coords) == 0

    def segment_count(self) -> int:
        """Return the number of segments."""

        n = self.point_count()

        return n - 1 if n > 1 else 0

    def get_point(self, index: int) -> Point | None:
        """Return the point at index, or None when out of range."""

        if index < 0 or index >= self.point_count():
            return None

        idx = index * 3

        return Point(self.coords[idx], self.coords[idx + 1], self.coords[idx + 2])

    def get_points(self) -> list[Point]:
        """Return all points."""

        points = []

        for i in range(self.point_count()):
            points.append(
                Point(
                    self.coords[i * 3], self.coords[i * 3 + 1], self.coords[i * 3 + 2]
                )
            )

        return points

    def get_lines(self) -> list[Line]:
        """Return one line per segment."""

        from .line import Line

        lines = []

        for i in range(self.segment_count()):
            idx0 = i * 3
            idx1 = (i + 1) * 3
            lines.append(
                Line(
                    self.coords[idx0],
                    self.coords[idx0 + 1],
                    self.coords[idx0 + 2],
                    self.coords[idx1],
                    self.coords[idx1 + 1],
                    self.coords[idx1 + 2],
                )
            )

        return lines

    def get_plane(self) -> Plane:
        """Return the plane from the first non-collinear triple, computed on first access."""

        if not self._plane_dirty or self.point_count() < 3:
            return self.plane

        n = self.point_count()
        p0 = self.get_point(0)
        found = False

        for i in range(1, n):
            if found:
                break

            v1 = self.get_point(i) - p0

            if v1.magnitude_squared() < 1e-20:
                continue

            for j in range(i + 1, n):
                if found:
                    break

                normal = v1.cross(self.get_point(j) - p0)

                if normal.magnitude_squared() < 1e-20:
                    continue

                normal.normalize_self()
                v1.normalize_self()
                yax = normal.cross(v1)
                yax.normalize_self()
                self.plane = Plane.from_frame(p0, v1, yax, normal)
                found = True

        if not found:
            self.plane = Plane()

        self._plane_dirty = False

        return self.plane

    def length(self) -> float:
        """Return the total length."""

        total = 0.0

        for i in range(self.segment_count()):
            total += math.sqrt(
                (self.get_point(i + 1) - self.get_point(i)).magnitude_squared()
            )

        return total

    def length_squared(self) -> float:
        """Return the sum of squared segment lengths."""

        total = 0.0

        for i in range(self.segment_count()):
            total += (self.get_point(i + 1) - self.get_point(i)).magnitude_squared()

        return total

    def is_closed(self) -> bool:
        """Return whether the first and last points coincide."""

        if self.point_count() < 2:
            return False

        return (
            self.get_point(0).distance(self.get_point(self.point_count() - 1))
            < Tolerance.ZERO_TOLERANCE
        )

    def closed(self) -> Polyline:
        """Return a copy with the first point appended when open."""

        if self.is_closed():
            return Polyline.from_coords(self.coords)

        coords = list(self.coords)
        coords.append(self.coords[0])
        coords.append(self.coords[1])
        coords.append(self.coords[2])

        return Polyline.from_coords(coords)

    def open_points(self) -> list[Point]:
        """Return the points without the closing duplicate."""

        points = self.get_points()

        if self.is_closed():
            points.pop()

        return points

    def center(self) -> Point:
        """Return the average of the points, closing duplicate excluded."""

        if not self.coords:
            return Point(0.0, 0.0, 0.0)

        n = self.point_count() - 1 if self.is_closed() else self.point_count()
        x = 0.0
        y = 0.0
        z = 0.0

        for i in range(n):
            x += self.coords[i * 3]
            y += self.coords[i * 3 + 1]
            z += self.coords[i * 3 + 2]

        return Point(x / n, y / n, z / n)

    def area(self) -> float:
        """Return the area of the planar polygon."""

        points = self.open_points()
        twice = Vector(0.0, 0.0, 0.0)

        for i in range(1, len(points) - 1):
            twice += (points[i] - points[0]).cross(points[i + 1] - points[0])

        return 0.5 * twice.magnitude()

    def area_centroid(self) -> Point:
        """Return the area centroid of the planar polygon."""

        points = self.open_points()
        n = len(points)
        normal = Polyline._newell_normal(points).normalized()
        origin = points[0]
        sum = Vector(0.0, 0.0, 0.0)
        area = 0.0

        for i in range(1, n - 1):
            weight = (points[i] - origin).cross(points[i + 1] - origin).dot(normal)
            sum += ((points[i] - origin) + (points[i + 1] - origin)) * (weight / 3.0)
            area += weight

        return origin + sum / area

    def get_average_plane(self) -> tuple[Point, Vector, Vector, Vector]:
        """Compute the frame with origin at center, x along the first segment, z the average normal."""

        origin = self.center()
        x_axis = (
            self.get_point(1) - self.get_point(0)
            if self.point_count() >= 2
            else Vector(1.0, 0.0, 0.0)
        )
        x_axis.normalize_self()
        z_axis = self._average_normal()
        y_axis = z_axis.cross(x_axis)
        y_axis.normalize_self()

        return (origin, x_axis, y_axis, z_axis)

    def get_fast_plane(self) -> tuple[Point, Plane]:
        """Compute the plane with origin at the first point, normal the average normal."""

        if not self.coords:
            return (Point(0.0, 0.0, 0.0), Plane())

        origin = self.get_point(0)
        normal = self._average_normal()

        return (origin, Plane.from_point_normal(origin, normal))

    def get_convex_corners(self) -> list[bool]:
        """Compute one flag per corner, true when convex against the average normal."""

        if self.point_count() < 3:
            return []

        n = self.point_count() - 1 if self.is_closed() else self.point_count()
        normal = self._average_normal()
        convex_or_concave = []

        for current in range(n):
            prev = n - 1 if current == 0 else current - 1
            next = 0 if current == n - 1 else current + 1
            dir0 = self.get_point(current) - self.get_point(prev)
            dir0.normalize_self()
            dir1 = self.get_point(next) - self.get_point(current)
            dir1.normalize_self()
            cross = dir0.cross(dir1)
            cross.normalize_self()
            convex_or_concave.append(cross.dot(normal) >= 0.0)

        return convex_or_concave

    def is_clockwise(self, pln: Plane) -> bool:
        """Return the shoelace sign of the points projected onto pln."""

        n = self.point_count()

        if n < 3:
            return False

        xv = pln.x_axis
        yv = pln.y_axis
        orig = pln.origin
        lim = n - 1 if self.is_closed() else n
        area = 0.0

        for i in range(lim):
            d0 = self.get_point(i) - orig
            d1 = self.get_point((i + 1) % lim) - orig
            u0 = d0.dot(xv)
            v0 = d0.dot(yv)
            u1 = d1.dot(xv)
            v1 = d1.dot(yv)
            area += (u1 - u0) * (v1 + v0)

        return area > 0

    def point_in_polygon_2d(self, p: Point) -> bool:
        """Return the winding-number test on x and y."""

        px = p[0]
        py = p[1]
        n = self.point_count()
        winding = 0

        for i in range(n):
            j = (i + 1) % n
            x0 = self.coords[i * 3]
            y0 = self.coords[i * 3 + 1]
            x1 = self.coords[j * 3]
            y1 = self.coords[j * 3 + 1]
            side = (x1 - x0) * (py - y0) - (px - x0) * (y1 - y0)

            if y0 <= py and y1 > py and side > 0.0:
                winding += 1
            elif y0 > py and y1 <= py and side < 0.0:
                winding -= 1

        return winding != 0

    def closest_distance_and_point(self, point: Point) -> tuple[float, int, Point]:
        """Return the distance to the nearest segment, with its index and the closest point."""

        edge_id = 0
        closest_distance = float("inf")
        best_t = 0.0

        for i in range(self.segment_count()):
            t = Polyline.closest_point_to_line(
                point, self.get_point(i), self.get_point(i + 1)
            )
            distance = point.distance(
                Polyline.point_at(self.get_point(i), self.get_point(i + 1), t)
            )

            if distance < closest_distance:
                closest_distance = distance
                edge_id = i
                best_t = t

            if closest_distance < Tolerance.ZERO_TOLERANCE:
                break

        closest_point = Polyline.point_at(
            self.get_point(edge_id), self.get_point(edge_id + 1), best_t
        )

        return (closest_distance, edge_id, closest_point)

    # ═══════════════════════════════════════════════════════════════════════════
    # Mutators
    # ═══════════════════════════════════════════════════════════════════════════
    def set_point(self, index: int, point: Point) -> None:
        """Set the point at index."""

        if index < 0 or index >= self.point_count():
            return

        idx = index * 3
        self.coords[idx] = point[0]
        self.coords[idx + 1] = point[1]
        self.coords[idx + 2] = point[2]

    def add_point(self, point: Point) -> None:
        """Append a point."""

        self.coords.extend([point[0], point[1], point[2]])

        if self.point_count() == 3:
            self._recompute_plane_if_needed()

    def insert_point(self, index: int, point: Point) -> None:
        """Insert a point at index."""

        if index < 0 or index > self.point_count():
            return

        idx = index * 3
        self.coords[idx:idx] = [point[0], point[1], point[2]]

        if self.point_count() == 3:
            self._recompute_plane_if_needed()

    def remove_point(self, index: int) -> Point | None:
        """Remove and return the point at index; None when out of range."""

        if index < 0 or index >= self.point_count():
            return None

        idx = index * 3
        out_point = Point(self.coords[idx], self.coords[idx + 1], self.coords[idx + 2])
        del self.coords[idx : idx + 3]

        if self.point_count() == 3:
            self._recompute_plane_if_needed()

        return out_point

    def reverse(self) -> None:
        """Reverse the point order in place."""

        n = self.point_count()
        coords = []

        for i in range(n, 0, -1):
            idx = (i - 1) * 3
            coords.extend(
                [self.coords[idx], self.coords[idx + 1], self.coords[idx + 2]]
            )

        self.coords = coords
        self.plane.reverse()

    def reversed(self) -> Polyline:
        """Return a reversed copy."""

        result = self.duplicate()
        result.reverse()

        return result

    def shift(self, times: int) -> None:
        """Rotate the points by times positions, keeping the closing duplicate."""

        if not self.coords:
            return

        was_closed = self.is_closed()

        if was_closed:
            del self.coords[-3:]

        n = self.point_count()

        if n > 0 and times != 0:
            offset = times % n
            coords = []

            for i in range(n):
                src = ((i + offset) % n) * 3
                coords.extend(
                    [self.coords[src], self.coords[src + 1], self.coords[src + 2]]
                )

            self.coords = coords

        if was_closed and n > 0:
            self.coords.extend([self.coords[0], self.coords[1], self.coords[2]])

    def translate(self, v: Vector) -> None:
        """Translate in place."""
        self += v

    def translated(self, v: Vector) -> Polyline:
        """Return a translated copy."""

        result = self.duplicate()
        result.translate(v)

        return result

    def extend_segment(
        self,
        segment_id: int,
        dist0: float,
        dist1: float,
        proportion0: float = 0.0,
        proportion1: float = 0.0,
    ) -> None:
        """Move the segment ends by dist0 and dist1, or by proportions of its length when non-zero."""

        if segment_id < 0 or segment_id >= self.segment_count():
            return

        if dist0 == 0 and dist1 == 0 and proportion0 == 0 and proportion1 == 0:
            return

        was_closed = self.is_closed()
        p0 = self.get_point(segment_id)
        p1 = self.get_point(segment_id + 1)
        v = p1 - p0

        if proportion0 != 0 or proportion1 != 0:
            p0 = p0 - v * proportion0
            p1 = p1 + v * proportion1
        else:
            v.normalize_self()
            p0 = p0 - v * dist0
            p1 = p1 + v * dist1

        self.set_point(segment_id, p0)
        self.set_point(segment_id + 1, p1)

        if not was_closed:
            return

        if segment_id == 0:
            self.set_point(self.point_count() - 1, self.get_point(0))
        elif segment_id + 1 == self.point_count() - 1:
            self.set_point(0, self.get_point(self.point_count() - 1))

    def extend_segment_equally(
        self, segment_id: int, dist: float, proportion: float = 0.0
    ) -> None:
        """Move both segment ends by dist, or by proportion of its length when non-zero."""

        if segment_id < 0 or segment_id >= self.segment_count():
            return

        closed = self.point_count() > 2 and self.is_closed()
        p0 = self.get_point(segment_id)
        p1 = self.get_point(segment_id + 1)
        Polyline.extend_segment_equally_static(p0, p1, dist, proportion)
        self.set_point(segment_id, p0)
        self.set_point(segment_id + 1, p1)

        if not closed:
            return

        if segment_id == 0:
            self.set_point(self.point_count() - 1, self.get_point(0))
        elif segment_id + 1 == self.point_count() - 1:
            self.set_point(0, self.get_point(self.point_count() - 1))

    def extend_edge_equally(self, edge_idx: int, distance: float) -> None:
        """Slide both ends of edge edge_idx outward by distance, keeping the closing duplicate in sync."""

        n = self.point_count()

        if n < 2 or edge_idx + 1 >= n:
            return

        i = edge_idx
        j = edge_idx + 1
        pi = self.get_point(i)
        pj = self.get_point(j)
        dir = pj - pi
        length = math.sqrt(dir.magnitude_squared())

        if length < 1e-12:
            return

        dir = dir * (distance / length)
        new_pi = pi - dir
        new_pj = pj + dir
        self.set_point(i, new_pi)
        self.set_point(j, new_pj)

        if i == 0:
            self.set_point(n - 1, new_pi)

        if j == n - 1:
            self.set_point(0, new_pj)

    def merge_collinear(self, tol: float = Tolerance.APPROXIMATION) -> None:
        """Drop points whose neighbours are collinear within tol; closed polylines wrap around."""

        closed = self.is_closed()
        points = self.get_points()

        if closed and len(points) > 1:
            points.pop()

        zt2 = Tolerance.ZERO_TOLERANCE * Tolerance.ZERO_TOLERANCE
        max_pass = len(points)
        changed = True

        for _ in range(max_pass):
            if not changed or len(points) < 3:
                break

            changed = False
            m = len(points)
            out = []

            for i in range(m):
                p = (i + m - 1) % m
                nx = (i + 1) % m

                if not closed and (i == 0 or i == m - 1):
                    out.append(points[i])
                    continue

                a = points[i] - points[p]
                b = points[nx] - points[i]
                a2 = a.magnitude_squared()
                b2 = b.magnitude_squared()

                if (
                    a2 < zt2
                    or b2 < zt2
                    or a.cross(b).magnitude_squared() < tol * tol * a2 * b2
                ):
                    changed = True
                else:
                    out.append(points[i])

            points = out

        if closed and points:
            points.append(points[0])

        self.coords = Polyline(points).coords
        self._recompute_plane_if_needed()

    def remove_consecutive_duplicates(
        self, tol: float = Tolerance.APPROXIMATION
    ) -> None:
        """Drop consecutive points closer than tol."""

        tol_sq = tol * tol
        cleaned = []

        for p in self.get_points():
            if not cleaned or (p - cleaned[-1]).magnitude_squared() >= tol_sq:
                cleaned.append(p)

        self.coords = Polyline(cleaned).coords
        self._recompute_plane_if_needed()

    def simplify(self, tolerance: float) -> Polyline:
        """Return a Ramer-Douglas-Peucker copy."""
        return Polyline(Polyline.simplify_points(self.get_points(), tolerance))

    def cut_by_plane(self, plane: Plane, flip: bool | None = None) -> Polyline:
        """Return the part on one side of plane; flip picks the normal side, unset keeps the arc-length midpoint side."""

        n = self.point_count()

        if n < 2:
            return self.duplicate()

        normal = plane.z_axis
        origin = plane.origin
        keep_sign = 1.0

        if flip is not None:
            keep_sign = 1.0 if flip else -1.0
        else:
            keep_sign = (
                1.0
                if normal.dot(self._point_at_length(self.length() * 0.5) - origin)
                >= 0.0
                else -1.0
            )

        result = []

        for i in range(n - 1):
            a = self.get_point(i)
            b = self.get_point(i + 1)
            da = normal.dot(a - origin)
            db = normal.dot(b - origin)

            if da * keep_sign >= 0.0:
                result.append(a)

            if (da > 0.0) != (db > 0.0):
                result.append(a + (b - a) * (da / (da - db)))

        last = self.get_point(n - 1)

        if normal.dot(last - origin) * keep_sign >= 0.0:
            result.append(last)

        cut = Polyline(result)
        cut.remove_consecutive_duplicates(1e-6)

        return cut

    def offset_sides(self, distances: list[float]) -> Polyline:
        """Return the loop closed with side i moved right of its direction in xy by distances[i], outwards for a counter-clockwise loop; corners mitred, the larger distance where two sides are parallel; empty for fewer than three corners or distances than sides."""

        points = self.get_points()

        if self.is_closed():
            points.pop()

        count = len(points)

        if count < 3 or len(distances) < count:
            return Polyline()

        outward = []

        for i in range(count):
            following = points[(i + 1) % count]
            outward.append(
                Vector(
                    following[1] - points[i][1], points[i][0] - following[0], 0.0
                ).normalized()
            )

        result = []

        for i in range(count):
            before = outward[(i + count - 1) % count]
            after = outward[i]
            moved_before = distances[(i + count - 1) % count]
            moved_after = distances[i]
            cosine = before.dot(after)

            if 1.0 - cosine * cosine < Tolerance.ABSOLUTE:
                result.append(points[i] + before * max(moved_before, moved_after))
            else:
                result.append(
                    points[i]
                    + before
                    * ((moved_before - cosine * moved_after) / (1.0 - cosine * cosine))
                    + after
                    * ((moved_after - cosine * moved_before) / (1.0 - cosine * cosine))
                )

        result.append(result[0])

        return Polyline(result)

    def offset_toward(self, distance: float, up: Vector) -> Polyline:
        """Return the copy with each segment moved by distance across it in the plane of the segment and up, the ends kept on the end planes; raises ValueError when three planes share no point."""

        from .intersection import plane_plane_plane
        from .line import Line

        points = self.get_points()
        n = len(points)

        if n < 2:
            return self.duplicate()

        planes = [Plane.from_point_normal(points[0], points[1] - points[0])]

        for i in range(n - 1):
            line = Line.from_points(points[i], points[i + 1])
            x = line.to_direction()
            y = up.cross(x)
            planes.append(
                Plane.from_point_normal(line.center(), x.cross(y)).translate_by_normal(
                    distance
                )
            )

        planes.append(
            Plane.from_point_normal(points[n - 1], points[n - 2] - points[n - 1])
        )

        base = Plane.from_point_normal(points[0], up.cross(points[n - 1] - points[0]))
        result = []

        for i in range(len(planes) - 1):
            point = plane_plane_plane(planes[i], planes[i + 1], base)

            if point is None:
                raise ValueError("offset_toward: three planes share no point")

            result.append(point)

        return Polyline(result)

    def extended(self, start: float, end: float) -> Polyline:
        """Return a copy with the first point pushed out by start and the last by end along their segments."""

        points = self.get_points()
        n = len(points)

        if n < 2:
            return self.duplicate()

        points[0] = points[0] + (points[0] - points[1]).normalized() * start
        points[n - 1] = (
            points[n - 1] + (points[n - 1] - points[n - 2]).normalized() * end
        )

        return Polyline(points)

    def trimmed(self, plane0: Plane, plane1: Plane, extension: float) -> Polyline:
        """Return the copy extended by extension at both ends and cut by both planes, each keeping the side of the original center."""

        middle = self.center()

        return (
            self.extended(extension, extension)
            .cut_by_plane(plane0, plane0.signed_distance(middle) >= 0.0)
            .cut_by_plane(plane1, plane1.signed_distance(middle) >= 0.0)
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # Operators
    # ═══════════════════════════════════════════════════════════════════════════
    def __eq__(self, other) -> bool:
        """Compare name, coordinates to 1e-6, width and linecolor; guid ignored."""

        if not isinstance(other, Polyline):
            return False

        if self.name != other.name:
            return False

        if self.point_count() != other.point_count():
            return False

        for i in range(len(self.coords)):
            if round(self.coords[i], Tolerance.ROUNDING) != round(
                other.coords[i], Tolerance.ROUNDING
            ):
                return False

        if round(self.width, Tolerance.ROUNDING) != round(
            other.width, Tolerance.ROUNDING
        ):
            return False

        return self.linecolor == other.linecolor

    def __ne__(self, other) -> bool:
        """Compare name, coordinates to 1e-6, width and linecolor; guid ignored."""
        return not self == other

    def __getitem__(self, index: int) -> Point:
        """Return the point at index."""

        if index < 0 or index >= self.point_count():
            raise IndexError("Index out of range")

        return self.get_point(index)

    def __setitem__(self, index: int, point: Point) -> None:
        """Set the point at index."""

        if index < 0 or index >= self.point_count():
            raise IndexError("Index out of range")

        self.set_point(index, point)

    def __iadd__(self, v: Vector) -> Polyline:
        """Translate in place."""

        for i in range(self.point_count()):
            self.coords[i * 3] += v[0]
            self.coords[i * 3 + 1] += v[1]
            self.coords[i * 3 + 2] += v[2]

        self.plane = Plane(self.plane.origin + v, self.plane.x_axis, self.plane.y_axis)

        return self

    def __isub__(self, v: Vector) -> Polyline:
        """Translate back in place."""

        for i in range(self.point_count()):
            self.coords[i * 3] -= v[0]
            self.coords[i * 3 + 1] -= v[1]
            self.coords[i * 3 + 2] -= v[2]

        self.plane = Plane(self.plane.origin - v, self.plane.x_axis, self.plane.y_axis)

        return self

    def __imul__(self, factor: float) -> Polyline:
        """Scale every point in place."""

        for i in range(len(self.coords)):
            self.coords[i] *= factor

        return self

    def __itruediv__(self, factor: float) -> Polyline:
        """Divide every point in place."""

        for i in range(len(self.coords)):
            self.coords[i] /= factor

        return self

    def __add__(self, v: Vector) -> Polyline:
        """Return a translated copy."""

        result = self.duplicate()
        result += v

        return result

    def __sub__(self, v: Vector) -> Polyline:
        """Return a copy translated back."""

        result = self.duplicate()
        result -= v

        return result

    def __mul__(self, factor: float) -> Polyline:
        """Return a scaled copy."""

        result = self.duplicate()
        result *= factor

        return result

    def __truediv__(self, factor: float) -> Polyline:
        """Return a divided copy."""

        result = self.duplicate()
        result /= factor

        return result

    def __neg__(self) -> Polyline:
        """Return a reversed copy."""
        return self.reversed()

    # ═══════════════════════════════════════════════════════════════════════════
    # Transformation
    # ═══════════════════════════════════════════════════════════════════════════
    def transform(self, xform: Xform) -> None:
        """Transform in place."""

        for i in range(self.point_count()):
            point = self.get_point(i)
            point.transform(xform)
            self.set_point(i, point)

    def transformed(self, xform: Xform) -> Polyline:
        """Return a transformed copy."""

        result = self.duplicate()
        result.transform(xform)

        return result

    # ═══════════════════════════════════════════════════════════════════════════
    # Segment utilities
    # ═══════════════════════════════════════════════════════════════════════════
    @staticmethod
    def point_at(start: Point, end: Point, t: float) -> Point:
        """Return the point at parameter t (0 = start, 1 = end)."""

        s = 1.0 - t

        return Point(
            start[0] if start[0] == end[0] else s * start[0] + t * end[0],
            start[1] if start[1] == end[1] else s * start[1] + t * end[1],
            start[2] if start[2] == end[2] else s * start[2] + t * end[2],
        )

    @staticmethod
    def closest_point_to_line(
        point: Point, line_start: Point, line_end: Point
    ) -> float:
        """Compute the parameter t of the closest point on the line through line_start and line_end."""

        d = line_end - line_start
        dod = d.magnitude_squared()

        if dod <= 0.0:
            return 0.0

        to_start = point - line_start
        to_end = point - line_end

        if to_start.magnitude_squared() <= to_end.magnitude_squared():
            return to_start.dot(d) / dod

        return 1.0 + to_end.dot(d) / dod

    @staticmethod
    def line_line_overlap(
        line0_start: Point, line0_end: Point, line1_start: Point, line1_end: Point
    ) -> tuple[Point, Point] | None:
        """Compute the collinear overlap of two segments; None when none or a single point."""

        do_overlap, overlap_start, overlap_end = Polyline._line_line_overlap_points(
            line0_start, line0_end, line1_start, line1_end
        )

        if not do_overlap:
            return None

        return (overlap_start, overlap_end)

    @staticmethod
    def line_line_average(
        line0_start: Point, line0_end: Point, line1_start: Point, line1_end: Point
    ) -> tuple[Point, Point]:
        """Compute the midpoints of the paired starts and ends."""

        output_start = line0_start.mid_point(line1_start)
        output_end = line0_end.mid_point(line1_end)

        return (output_start, output_end)

    @staticmethod
    def line_line_overlap_average(
        line0_start: Point, line0_end: Point, line1_start: Point, line1_end: Point
    ) -> tuple[Point, Point]:
        """Compute the longer of the two midpoint pairings of the mutual overlaps."""

        _, line_a_start, line_a_end = Polyline._line_line_overlap_points(
            line0_start, line0_end, line1_start, line1_end
        )
        _, line_b_start, line_b_end = Polyline._line_line_overlap_points(
            line1_start, line1_end, line0_start, line0_end
        )
        mid_line0_start, mid_line0_end = Polyline.line_line_average(
            line_a_start, line_a_end, line_b_start, line_b_end
        )
        mid_line1_start, mid_line1_end = Polyline.line_line_average(
            line_a_start, line_a_end, line_b_end, line_b_start
        )

        if (mid_line0_end - mid_line0_start).magnitude_squared() > (
            mid_line1_end - mid_line1_start
        ).magnitude_squared():
            return (mid_line0_start, mid_line0_end)

        return (mid_line1_start, mid_line1_end)

    @staticmethod
    def line_from_projected_points(
        line_start: Point, line_end: Point, points: list[Point]
    ) -> tuple[Point, Point] | None:
        """Compute the extreme sub-segment of the line spanned by the projected points; None when a single point."""

        if not points:
            return None

        t_values = []

        for point in points:
            t_values.append(Polyline.closest_point_to_line(point, line_start, line_end))

        t_values.sort()
        output_start = Polyline.point_at(line_start, line_end, t_values[0])
        output_end = Polyline.point_at(line_start, line_end, t_values[-1])

        if abs(t_values[0] - t_values[-1]) <= Tolerance.ZERO_TOLERANCE:
            return None

        return (output_start, output_end)

    @staticmethod
    def extend_segment_equally_static(
        segment_start: Point, segment_end: Point, dist: float, proportion: float = 0.0
    ) -> None:
        """Move both ends by dist, or by proportion of the length when non-zero."""

        if dist == 0 and proportion == 0:
            return

        v = segment_end - segment_start

        if proportion != 0:
            segment_start -= v * proportion
            segment_end += v * proportion
        else:
            v.normalize_self()
            segment_start -= v * dist
            segment_end += v * dist

    @staticmethod
    def extend_line_segment(start: Point, end: Point, d0: float, d1: float) -> None:
        """Move start by d0 and end by d1 along the unit direction."""

        v = end - start
        v.normalize_self()
        start -= v * d0
        end += v * d1

    @staticmethod
    def shrink_line_segment(start: Point, end: Point, dist: float) -> None:
        """Move both ends inward by dist as a fraction of the length."""

        v = end - start
        start += v * dist
        end -= v * dist

    # ═══════════════════════════════════════════════════════════════════════════
    # Polygon utilities
    # ═══════════════════════════════════════════════════════════════════════════
    @staticmethod
    def tween_two_polylines(
        polyline0: Polyline, polyline1: Polyline, weight: float
    ) -> Polyline:
        """Return the pointwise blend; polyline0 when the counts differ."""

        if polyline0.point_count() != polyline1.point_count():
            return polyline0.duplicate()

        result = Polyline()

        for i in range(polyline0.point_count()):
            p0 = polyline0.get_point(i)
            p1 = polyline1.get_point(i)
            result.add_point(p0 + (p1 - p0) * weight)

        return result

    @staticmethod
    def interpolate_points(
        from_pt: Point, to_pt: Point, steps: int, kind: int = 0
    ) -> list[Point]:
        """Return steps points between from and to; kind 0 none, 1 both, 2 start endpoint."""
        return Point.interpolate(from_pt, to_pt, steps, kind)

    @staticmethod
    def quick_hull(polygon: Polyline) -> Polyline:
        """Return the convex hull in the polygon's average plane."""

        origin, xa, ya, _ = polygon.get_average_plane()

        pts2d = polygon._project_to_plane(origin, xa, ya)
        ai = 0
        bi = 0

        for i in range(1, len(pts2d)):
            if pts2d[i][0] < pts2d[ai][0]:
                ai = i

            if pts2d[i][0] >= pts2d[bi][0]:
                bi = i

        ax = pts2d[ai][0]
        ay = pts2d[ai][1]
        bx = pts2d[bi][0]
        by = pts2d[bi][1]
        left = []
        right = []

        for p in pts2d:
            if _ccw_2d(ax, ay, bx, by, p[0], p[1]) > 0.0:
                left.append(p)
            else:
                right.append(p)

        hull = [(ax, ay)]
        Polyline._quick_hull_recurse(left, ax, ay, bx, by, hull)
        hull.append((bx, by))
        Polyline._quick_hull_recurse(right, bx, by, ax, ay, hull)

        pts3d = []

        for h in hull:
            pts3d.append(Polyline._unproject(origin, xa, ya, h[0], h[1]))

        return Polyline(pts3d)

    @staticmethod
    def _rotated_extents_2d(
        pts2d: list[tuple[float, float]], ca: float, sa: float
    ) -> tuple[float, float, float, float]:
        """Return the extents (min_u, max_u, min_v, max_v) of pts2d in the frame rotated by cosine ca and sine sa."""

        min_u = float("inf")
        max_u = float("-inf")
        min_v = float("inf")
        max_v = float("-inf")

        for h in pts2d:
            u = h[0] * ca + h[1] * sa
            v = -h[0] * sa + h[1] * ca
            min_u = min(min_u, u)
            max_u = max(max_u, u)
            min_v = min(min_v, v)
            max_v = max(max_v, v)

        return (min_u, max_u, min_v, max_v)

    @staticmethod
    def _unproject_rectangle(
        origin: Point,
        x_axis: Vector,
        y_axis: Vector,
        extents: tuple[float, float, float, float],
        angle: float,
    ) -> Polyline:
        """Return the closed rectangle of extents rotated by angle in the frame (origin, x_axis, y_axis)."""

        ca = math.cos(angle)
        sa = math.sin(angle)
        uv = [
            (extents[0], extents[2]),
            (extents[0], extents[3]),
            (extents[1], extents[3]),
            (extents[1], extents[2]),
        ]
        pts3d = []

        for c in uv:
            pts3d.append(
                Polyline._unproject(
                    origin, x_axis, y_axis, c[0] * ca - c[1] * sa, c[0] * sa + c[1] * ca
                )
            )

        pts3d.append(pts3d[0])

        return Polyline(pts3d)

    @staticmethod
    def bounding_rectangle(polygon: Polyline) -> Polyline | None:
        """Return the minimum-area rectangle of the hull as a closed 5-point polyline."""

        hull = Polyline.quick_hull(polygon)

        if hull.point_count() <= 2:
            return None

        origin, xa, ya, _ = polygon.get_average_plane()

        hull2d = hull._project_to_plane(origin, xa, ya)
        best_area = float("inf")
        best_extents = (0.0, 0.0, 0.0, 0.0)
        best_angle = 0.0
        hn = len(hull2d)

        for i in range(hn):
            j = (i + 1) % hn
            ex = hull2d[j][0] - hull2d[i][0]
            ey = hull2d[j][1] - hull2d[i][1]
            length = math.sqrt(ex * ex + ey * ey)

            if length < 1e-12:
                continue

            extents = Polyline._rotated_extents_2d(hull2d, ex / length, ey / length)
            area = (extents[1] - extents[0]) * (extents[3] - extents[2])

            if area < best_area:
                best_area = area
                best_extents = extents
                best_angle = math.atan2(ey, ex)

        return Polyline._unproject_rectangle(origin, xa, ya, best_extents, best_angle)

    @staticmethod
    def trimmed_alike(
        polylines: list[Polyline], plane0: Plane, plane1: Plane, extension: float
    ) -> list[Polyline]:
        """Return polylines of one vertex count extended by extension and cut on the segments the first crosses, so quads between them stay quads; raises ValueError on mixed counts or a missed plane."""

        from .intersection import line_plane
        from .line import Line

        if not polylines:
            return []

        first = polylines[0].extended(extension, extension).get_points()
        a = Polyline._crossed_segment(first, plane0)
        b = Polyline._crossed_segment(first, plane1)

        if a == len(first) or b == len(first):
            raise ValueError("trimmed_alike: a plane misses the extended polyline")

        start = min(a, b)
        end = max(a, b)
        cut0 = plane0 if a <= b else plane1
        cut1 = plane1 if a <= b else plane0
        result = []

        for polyline in polylines:
            if polyline.point_count() != polylines[0].point_count():
                raise ValueError("trimmed_alike: polylines of different vertex counts")

            points = polyline.extended(extension, extension).get_points()
            head = line_plane(
                Line.from_points(points[start], points[start + 1]), cut0, False
            )
            tail = line_plane(
                Line.from_points(points[end], points[end + 1]), cut1, False
            )

            if head is None or tail is None:
                raise ValueError(
                    "trimmed_alike: an end segment runs parallel to its plane"
                )

            kept = [head]
            kept.extend(points[start + 1 : end + 1])
            kept.append(tail)
            result.append(Polyline(kept))

        return result

    @staticmethod
    def grid_of_points_in_polygon(
        polygon: Polyline, offset_dist: float, div_dist: float, max_pts: int = 100
    ) -> list[Point]:
        """Return a grid of interior points spaced div_dist, on the polygon miter-offset by offset_dist."""

        if div_dist < 1e-12:
            return []

        origin, xa, ya, _ = polygon.get_average_plane()

        poly2d = polygon._project_to_plane(origin, xa, ya)

        if (
            len(poly2d) > 1
            and polygon.get_point(0).distance(
                polygon.get_point(polygon.point_count() - 1)
            )
            < 1e-10
        ):
            poly2d.pop()

        if not poly2d:
            return []

        poly2d = Polyline._offset_polygon_2d(poly2d, offset_dist)
        x_min = float("inf")
        x_max = float("-inf")
        y_min = float("inf")
        y_max = float("-inf")

        for p in poly2d:
            x_min = min(x_min, p[0])
            x_max = max(x_max, p[0])
            y_min = min(y_min, p[1])
            y_max = max(y_max, p[1])

        result = []
        u = x_min

        while u <= x_max + 1e-10 and len(result) < max_pts:
            v = y_min

            while v <= y_max + 1e-10 and len(result) < max_pts:
                if Polyline._point_in_polygon(poly2d, u, v):
                    result.append(Polyline._unproject(origin, xa, ya, u, v))

                v += div_dist

            u += div_dist

        return result

    @staticmethod
    def polylabel(
        polylines: list[Polyline], precision: float = 1.0
    ) -> tuple[Point, Plane, float]:
        """Return the largest inscribed circle of polylines[0] minus the holes polylines[1..]: center, plane, radius."""

        if not polylines:
            return (Point(0.0, 0.0, 0.0), Plane(), 0.0)

        origin, xa, ya, za = polylines[0].get_average_plane()

        rings2d = []
        sizes = []

        for pl in polylines:
            ring = pl._project_to_plane(origin, xa, ya)

            if (
                len(ring) > 1
                and pl.get_point(0).distance(pl.get_point(pl.point_count() - 1)) < 1e-10
            ):
                ring.pop()

            mnx = float("inf")
            mny = float("inf")
            mxx = float("-inf")
            mxy = float("-inf")

            for uv in ring:
                mnx = min(mnx, uv[0])
                mxx = max(mxx, uv[0])
                mny = min(mny, uv[1])
                mxy = max(mxy, uv[1])

            rings2d.append(ring)
            sizes.append((mxx - mnx) * (mxx - mnx) + (mxy - mny) * (mxy - mny))

        order = []

        for i in range(len(rings2d)):
            order.append((-sizes[i], i))

        order.sort()
        polygon = []

        for item in order:
            polygon.append(rings2d[item[1]])

        cr = _mapbox_polylabel(polygon, precision)
        center = Polyline._unproject(origin, xa, ya, cr[0], cr[1])

        return (center, Plane.from_frame(origin, xa, ya, za), cr[2])

    @staticmethod
    def polylabel_circle_division_points(
        division_direction_in_3d: Vector,
        polylines: list[Polyline],
        division: int = 4,
        scale: float = 0.75,
        precision: float = 1.0,
        orient_to_closest_edge: bool = True,
    ) -> list[Point]:
        """Return division points on the polylabel circle scaled by scale, oriented to the closest edge or division_direction_in_3d."""

        center, plane, r = Polyline.polylabel(polylines, precision)
        radius = r * scale
        is_direction_valid = (
            division_direction_in_3d[0] != 0.0
            or division_direction_in_3d[1] != 0.0
            or division_direction_in_3d[2] != 0.0
        )
        found, edge_i, edge_j = Polyline._closest_edge(center, polylines)
        found = orient_to_closest_edge and found
        x_axis = plane.x_axis
        y_axis = plane.y_axis
        z_axis = plane.z_axis

        if is_direction_valid or orient_to_closest_edge:
            dir = (
                polylines[edge_i].get_point(edge_j + 1)
                - polylines[edge_i].get_point(edge_j)
                if found
                else division_direction_in_3d
            )
            x_axis = Vector(dir[0], dir[1], dir[2])
            y_axis = dir.cross(z_axis)

        x_axis.normalize_self()
        y_axis.normalize_self()
        z_axis.normalize_self()

        points = []
        chunk = 360.0 / division

        for i in range(division):
            rad = (45.0 + i * chunk) * Tolerance.PI / 180.0
            points.append(
                Polyline._unproject(
                    center,
                    x_axis,
                    y_axis,
                    radius * math.cos(rad),
                    radius * math.sin(rad),
                )
            )

        return points

    @staticmethod
    def boolean_op(
        a: Polyline, b: Polyline, clip_type: int, plane: Plane | None = None
    ) -> list[Polyline]:
        """Return the Vatti boolean of two closed polylines on x and y, or in plane's local frame; clip_type 0 intersection, 1 union, 2 a minus b."""

        from .boolean_polyline import BooleanPolyline

        if plane is None:
            return BooleanPolyline.compute(a, b, clip_type)

        pa2d = Polyline._boolean_project(a, plane)
        pb2d = Polyline._boolean_project(b, plane)
        Polyline._ensure_ccw(pa2d)
        Polyline._ensure_ccw(pb2d)

        results = BooleanPolyline.compute(pa2d, pb2d, clip_type)
        o = plane.origin
        x = plane.x_axis
        y = plane.y_axis

        for r in results:
            for i in range(r.point_count()):
                r.set_point(
                    i,
                    Polyline._unproject(o, x, y, r.coords[i * 3], r.coords[i * 3 + 1]),
                )

        return results

    @staticmethod
    def simplify_points(points: list[Point], tolerance: float) -> list[Point]:
        """Return the Ramer-Douglas-Peucker simplification of a point list."""

        n = len(points)

        if n < 3:
            return list(points)

        keep = [False] * n
        keep[0] = True
        keep[n - 1] = True
        Polyline._simplify_rdp(points, 0, n - 1, tolerance, keep)

        result = []

        for i in range(n):
            if keep[i]:
                result.append(points[i])

        return result

    @staticmethod
    def two_rects_from_frame(
        p: Point,
        segment_vector: Vector,
        zaxis: Vector,
        middle: bool,
        radius: float,
        length: float,
        flip_male: int,
    ) -> tuple[Polyline, Polyline]:
        """Compute male rect0 and female rect1 cross-sections of radius about p along segment_vector; flip_male rotates the corners."""

        y_axis = zaxis.cross(segment_vector)
        x_axis = y_axis.cross(segment_vector)
        x_axis.normalize_self()
        y_axis.normalize_self()
        x_axis = x_axis * radius
        y_axis = y_axis * radius
        sv0 = segment_vector * (length * -0.5)
        sv1 = segment_vector * (length * 0.5)
        v = [-x_axis - y_axis, x_axis - y_axis, x_axis + y_axis, -x_axis + y_axis]

        if not middle and flip_male == 1:
            v = v[1:] + v[:1]
        elif not middle and flip_male == -1:
            v = v[-1:] + v[:-1]

        rect0 = Polyline(
            [
                p + sv0 + v[1],
                p + sv1 + v[1],
                p + sv1 + v[0],
                p + sv0 + v[0],
                p + sv0 + v[1],
            ]
        )
        rect1 = Polyline(
            [
                p + sv0 + v[2],
                p + sv1 + v[2],
                p + sv1 + v[3],
                p + sv0 + v[3],
                p + sv0 + v[2],
            ]
        )

        return (rect0, rect1)

    @staticmethod
    def trim_rectangles_by_plane(
        first: Polyline, second: Polyline, plane: Plane
    ) -> bool:
        """Cut two closed 5-point rectangles at plane, keeping the side on the positive half; false when a long edge misses the plane."""

        from .intersection import line_plane
        from .line import Line

        if first.point_count() != 5 or second.point_count() != 5:
            return False

        points = [
            line_plane(Line.from_points(first[0], first[1]), plane, False),
            line_plane(Line.from_points(first[3], first[2]), plane, False),
            line_plane(Line.from_points(second[0], second[1]), plane, False),
            line_plane(Line.from_points(second[3], second[2]), plane, False),
        ]

        for point in points:
            if point is None:
                return False

            for i in range(3):
                if not math.isfinite(point[i]):
                    return False

        if plane.has_on_negative_side(first[0]):
            first.set_point(0, points[0])
            first.set_point(3, points[1])
            first.set_point(4, points[0])
            second.set_point(0, points[2])
            second.set_point(3, points[3])
            second.set_point(4, points[2])
        else:
            first.set_point(1, points[0])
            first.set_point(2, points[1])
            second.set_point(1, points[2])
            second.set_point(2, points[3])

        return True

    # ═══════════════════════════════════════════════════════════════════════════
    # JSON
    # ═══════════════════════════════════════════════════════════════════════════
    def __jsondump__(self) -> dict:
        """Serialize to a JSON object."""

        return {
            "coords": self.coords,
            "dash": list(self.dash),
            "guid": self.guid,
            "is_locked": self.is_locked,
            "is_visible": self.is_visible,
            "linecolor": self.linecolor.__jsondump__(),
            "name": self.name,
            "type": "Polyline",
            "width": self.width,
        }

    @classmethod
    def __jsonload__(
        cls, data: dict, guid: str | None = None, name: str | None = None
    ) -> Polyline:
        """Deserialize from a JSON object."""

        from .file_encoders import file_decode_node

        polyline = cls()
        polyline.guid = guid if guid is not None else data.get("guid", polyline.guid)
        polyline.name = name if name is not None else data.get("name", polyline.name)
        polyline.is_visible = data.get("is_visible", True)
        polyline.is_locked = data.get("is_locked", False)

        if "coords" in data:
            polyline.coords = list(data["coords"])
        elif "points" in data:
            for point in data["points"]:
                polyline.add_point(file_decode_node(point))

        if "width" in data:
            polyline.width = data["width"]

        if "dash" in data:
            polyline.dash = list(data["dash"])

        if "linecolor" in data:
            polyline.linecolor = file_decode_node(data["linecolor"])

        polyline._recompute_plane_if_needed()

        return polyline

    def file_json_dumps(self) -> str:
        """Serialize to a JSON string."""
        return json.dumps(self.__jsondump__(), separators=(",", ":"))

    @classmethod
    def file_json_loads(cls, json_string: str) -> Polyline:
        """Deserialize from a JSON string."""
        return cls.__jsonload__(json.loads(json_string))

    def file_json_dump(self, filename: str | Path) -> None:
        """Write to a JSON file."""

        with open(filename, "w") as file:
            json.dump(self.__jsondump__(), file, indent=4)

    @classmethod
    def file_json_load(cls, filename: str | Path) -> Polyline:
        """Read from a JSON file."""

        with open(filename) as file:
            return cls.__jsonload__(json.load(file))

    # ═══════════════════════════════════════════════════════════════════════════
    # Protobuf
    # ═══════════════════════════════════════════════════════════════════════════
    def to_proto(self) -> polyline_pb2.Polyline:
        """Convert to the protobuf message."""

        from .proto import polyline_pb2

        proto = polyline_pb2.Polyline()

        if self.has_guid():
            proto.guid = self.guid

        proto.name = self.name

        if not self.is_visible:
            proto.is_visible = False

        if self.is_locked:
            proto.is_locked = True

        proto.width = self.width

        for d in self.dash:
            proto.dash.append(d)

        for c in self.coords:
            proto.coords.append(c)

        proto.linecolor.CopyFrom(self.linecolor.to_proto())

        return proto

    @classmethod
    def from_proto(cls, proto: polyline_pb2.Polyline) -> Polyline:
        """Construct from the protobuf message."""

        polyline = cls.from_coords(list(proto.coords))

        if proto.guid:
            polyline.guid = proto.guid

        polyline.name = proto.name
        polyline.is_visible = not proto.HasField("is_visible") or proto.is_visible
        polyline.is_locked = proto.is_locked
        polyline.width = proto.width
        polyline.dash = list(proto.dash)

        if proto.HasField("linecolor"):
            polyline.linecolor = Color.from_proto(proto.linecolor)

        return polyline

    def pb_dumps(self) -> bytes:
        """Serialize to protobuf bytes."""
        return self.to_proto().SerializeToString()

    @classmethod
    def pb_loads(cls, data: bytes) -> Polyline:
        """Deserialize from protobuf bytes."""

        from .proto import polyline_pb2

        proto = polyline_pb2.Polyline()
        proto.ParseFromString(data)

        return cls.from_proto(proto)

    def pb_dump(self, filename: str | Path) -> None:
        """Write to a protobuf file."""

        with open(filename, "wb") as file:
            file.write(self.pb_dumps())

    @classmethod
    def pb_load(cls, filename: str | Path) -> Polyline:
        """Read from a protobuf file."""

        with open(filename, "rb") as file:
            return cls.pb_loads(file.read())

    # ═══════════════════════════════════════════════════════════════════════════
    # String
    # ═══════════════════════════════════════════════════════════════════════════
    def __str__(self) -> str:
        """Return "[(x0, y0, z0), (x1, y1, z1), ...]"."""

        points = []

        for i in range(self.point_count()):
            points.append(
                f"({self.coords[i * 3]}, {self.coords[i * 3 + 1]}, {self.coords[i * 3 + 2]})"
            )

        return "[" + ", ".join(points) + "]"

    def __repr__(self) -> str:
        """Return "Polyline(name, N points)"."""
        return f"Polyline({self.name}, {self.point_count()} points)"

    # ═══════════════════════════════════════════════════════════════════════════
    # Private helpers
    # ═══════════════════════════════════════════════════════════════════════════
    def _recompute_plane_if_needed(self) -> None:
        """Mark the plane dirty so get_plane recomputes it."""
        self._plane_dirty = True

    def _average_normal(self) -> Vector:
        """Compute the average normal by Newell's method."""

        if self.point_count() < 3:
            return Vector(0.0, 0.0, 1.0)

        n = self.point_count() - 1 if self.is_closed() else self.point_count()
        avg_normal = Vector(0.0, 0.0, 0.0)

        for i in range(n):
            prev = n - 1 if i == 0 else i - 1
            next = (i + 1) % n
            v1 = self.get_point(i) - self.get_point(prev)
            v2 = self.get_point(next) - self.get_point(i)
            avg_normal += v1.cross(v2)

        avg_normal.normalize_self()

        return avg_normal

    def _point_at_length(self, distance: float) -> Point:
        """Return the point at arc length distance from the start."""

        acc = 0.0

        for i in range(self.point_count() - 1):
            a = self.get_point(i)
            b = self.get_point(i + 1)
            seg_len = (b - a).magnitude()

            if acc + seg_len >= distance:
                t = (distance - acc) / seg_len if seg_len > 1e-14 else 0.0

                return a + (b - a) * t

            acc += seg_len

        return self.get_point(0)

    def _project_to_plane(
        self, origin: Point, x_axis: Vector, y_axis: Vector
    ) -> list[tuple[float, float]]:
        """Compute the 2D coordinates of the points in the frame (origin, x_axis, y_axis)."""

        pts2d = []

        for i in range(self.point_count()):
            d = self.get_point(i) - origin
            pts2d.append((d.dot(x_axis), d.dot(y_axis)))

        return pts2d

    @staticmethod
    def _unproject(
        origin: Point, x_axis: Vector, y_axis: Vector, u: float, v: float
    ) -> Point:
        """Return the 3D point of (u, v) in the frame (origin, x_axis, y_axis)."""
        return origin + x_axis * u + y_axis * v

    @staticmethod
    def _line_line_overlap_points(
        line0_start: Point, line0_end: Point, line1_start: Point, line1_end: Point
    ) -> tuple[bool, Point, Point]:
        """Compute the collinear overlap of two segments as points; False when none or a single point."""

        t = [0.0, 1.0, 0.0, 0.0]
        t[2] = Polyline.closest_point_to_line(line1_start, line0_start, line0_end)
        t[3] = Polyline.closest_point_to_line(line1_end, line0_start, line0_end)
        do_overlap = not ((t[2] < 0 and t[3] < 0) or (t[2] > 1 and t[3] > 1))
        t.sort()
        do_overlap = do_overlap and abs(t[2] - t[1]) > Tolerance.ZERO_TOLERANCE
        overlap_start = Polyline.point_at(line0_start, line0_end, t[1])
        overlap_end = Polyline.point_at(line0_start, line0_end, t[2])

        return (do_overlap, overlap_start, overlap_end)

    @staticmethod
    def _quick_hull_recurse(
        pts: list[tuple[float, float]],
        ax: float,
        ay: float,
        bx: float,
        by: float,
        hull: list[tuple[float, float]],
    ) -> None:
        """Add the hull points of pts right of the segment (a, b) to hull."""

        if not pts:
            return

        fi = 0
        best = float("-inf")

        for i in range(len(pts)):
            val = _ccw_2d(ax, ay, bx, by, pts[i][0], pts[i][1])

            if val >= best:
                best = val
                fi = i

        fx = pts[fi][0]
        fy = pts[fi][1]
        left = []
        right = []

        for p in pts:
            if _ccw_2d(ax, ay, fx, fy, p[0], p[1]) > 0.0:
                left.append(p)

            if _ccw_2d(fx, fy, bx, by, p[0], p[1]) > 0.0:
                right.append(p)

        Polyline._quick_hull_recurse(left, ax, ay, fx, fy, hull)
        hull.append((fx, fy))
        Polyline._quick_hull_recurse(right, fx, fy, bx, by, hull)

    @staticmethod
    def _shoelace_2d(poly2d: list[tuple[float, float]]) -> float:
        """Return twice the signed area of a 2D polygon by the shoelace formula."""

        n = len(poly2d)
        area = 0.0

        for i in range(n):
            a = poly2d[i]
            b = poly2d[(i + 1) % n]
            area += a[0] * b[1] - b[0] * a[1]

        return area

    @staticmethod
    def _edge_normals_2d(
        poly2d: list[tuple[float, float]],
    ) -> list[tuple[float, float]]:
        """Return the unit normal of every edge of a 2D polygon, zero for a degenerate edge."""

        n = len(poly2d)
        normals = []

        for i in range(n):
            a = poly2d[i]
            b = poly2d[(i + 1) % n]
            ex = b[0] - a[0]
            ey = b[1] - a[1]
            length = math.sqrt(ex * ex + ey * ey)

            if length < 1e-12:
                normals.append((0.0, 0.0))
            else:
                normals.append((ey / length, -ex / length))

        return normals

    @staticmethod
    def _offset_polygon_2d(
        poly2d: list[tuple[float, float]], offset_dist: float
    ) -> list[tuple[float, float]]:
        """Miter-offset a 2D polygon by offset_dist."""

        n = len(poly2d)

        if offset_dist == 0.0 or n < 3:
            return poly2d

        delta = -offset_dist if Polyline._shoelace_2d(poly2d) < 0.0 else offset_dist
        normals = Polyline._edge_normals_2d(poly2d)
        out = []

        for i in range(n):
            np = normals[(i + n - 1) % n]
            nn = normals[i]
            cos_a = np[0] * nn[0] + np[1] * nn[1]
            sin_a = np[0] * nn[1] - np[1] * nn[0]
            denom = 1.0 + cos_a
            concave = cos_a > -0.999 and sin_a * delta < 0.0 and offset_dist > 0.0

            if concave:
                out.append((poly2d[i][0] + np[0] * delta, poly2d[i][1] + np[1] * delta))
                out.append((poly2d[i][0], poly2d[i][1]))
                out.append((poly2d[i][0] + nn[0] * delta, poly2d[i][1] + nn[1] * delta))
            elif abs(denom) < 1e-9:
                out.append(
                    (
                        poly2d[i][0] + (np[0] + nn[0]) * 0.5 * delta,
                        poly2d[i][1] + (np[1] + nn[1]) * 0.5 * delta,
                    )
                )
            else:
                out.append(
                    (
                        poly2d[i][0] + (np[0] + nn[0]) / denom * delta,
                        poly2d[i][1] + (np[1] + nn[1]) / denom * delta,
                    )
                )

        if len(out) >= 3 and abs(Polyline._shoelace_2d(out)) > 1e-4:
            return out

        return poly2d

    @staticmethod
    def _point_in_polygon(
        poly2d: list[tuple[float, float]], px: float, py: float
    ) -> bool:
        """Return whether (px, py) is inside poly2d by ray crossing."""

        n = len(poly2d)
        inside = False
        j = n - 1

        for i in range(n):
            xi = poly2d[i][0]
            yi = poly2d[i][1]
            xj = poly2d[j][0]
            yj = poly2d[j][1]

            if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                inside = not inside

            j = i

        return inside

    @staticmethod
    def _closest_edge(
        center: Point, polylines: list[Polyline]
    ) -> tuple[bool, int, int]:
        """Find the polyline and edge closest to center."""

        edge_i = 0
        edge_j = 0
        best_sq = float("inf")

        for i in range(len(polylines)):
            for j in range(polylines[i].point_count() - 1):
                a = polylines[i].get_point(j)
                e = polylines[i].get_point(j + 1) - a
                len2 = e.magnitude_squared()

                if len2 <= 0.0:
                    continue

                t = (center - a).dot(e) / len2

                if t < 0.0 or t > 1.0:
                    continue

                d2 = (center - (a + e * t)).magnitude_squared()

                if d2 < best_sq:
                    best_sq = d2
                    edge_i = i
                    edge_j = j

        return (best_sq < float("inf"), edge_i, edge_j)

    @staticmethod
    def _newell_normal(points: list[Point]) -> Vector:
        """Return Newell's unit normal of the loop through points, the closing edge included."""

        n = len(points)
        zero = Point(0.0, 0.0, 0.0)
        normal = Vector(0.0, 0.0, 0.0)

        for i in range(n):
            normal += (points[i] - zero).cross(points[(i + 1) % n] - zero)

        return normal.normalized()

    @staticmethod
    def _crossed_segment(points: list[Point], plane: Plane) -> int:
        """Return the first segment whose ends lie on both sides of plane, len(points) when none."""

        for i in range(len(points) - 1):
            if (plane.signed_distance(points[i]) >= 0.0) != (
                plane.signed_distance(points[i + 1]) >= 0.0
            ):
                return i

        return len(points)

    @staticmethod
    def _boolean_project(pl: Polyline, plane: Plane) -> Polyline:
        """Return pl projected into plane's local frame as 2D."""

        o = plane.origin
        x = plane.x_axis
        y = plane.y_axis
        n = pl.point_count()
        p2d = Polyline()
        p2d.coords = [0.0] * (n * 3)

        for i in range(n):
            d = pl.get_point(i) - o
            p2d.coords[i * 3] = d.dot(x)
            p2d.coords[i * 3 + 1] = d.dot(y)
            p2d.coords[i * 3 + 2] = 0.0

        if n >= 4:
            dx = p2d.coords[(n - 1) * 3] - p2d.coords[0]
            dy = p2d.coords[(n - 1) * 3 + 1] - p2d.coords[1]

            if dx * dx + dy * dy < 1.0:
                p2d.coords[(n - 1) * 3] = p2d.coords[0]
                p2d.coords[(n - 1) * 3 + 1] = p2d.coords[1]

        return p2d

    @staticmethod
    def _ensure_ccw(p2d: Polyline) -> None:
        """Reverse p2d in place when it winds clockwise."""

        n = p2d.point_count()
        m = n

        if m >= 4:
            dx = p2d.coords[(m - 1) * 3] - p2d.coords[0]
            dy = p2d.coords[(m - 1) * 3 + 1] - p2d.coords[1]

            if dx * dx + dy * dy < 1e-10:
                m -= 1

        if m < 3:
            return

        area = 0.0

        for i in range(m):
            j = (i + 1) % m
            area += (
                p2d.coords[i * 3] * p2d.coords[j * 3 + 1]
                - p2d.coords[j * 3] * p2d.coords[i * 3 + 1]
            )

        if area < 0.0:
            p2d.reverse()

    @staticmethod
    def _simplify_perp_dist(pt: Point, line_start: Point, line_end: Point) -> float:
        """Return the perpendicular distance from pt to the line through line_start and line_end."""

        d = line_end - line_start
        len_sq = d.magnitude_squared()

        if len_sq == 0.0:
            return math.sqrt((pt - line_start).magnitude_squared())

        t = (pt - line_start).dot(d) / len_sq
        t = max(0.0, min(1.0, t))

        return math.sqrt((pt - (line_start + d * t)).magnitude_squared())

    @staticmethod
    def _simplify_rdp(
        points: list[Point], start: int, end: int, tolerance: float, keep: list[bool]
    ) -> None:
        """Mark the points to keep between start and end by recursive Ramer-Douglas-Peucker."""

        if end <= start + 1:
            return

        max_dist = 0.0
        max_idx = start

        for i in range(start + 1, end):
            d = Polyline._simplify_perp_dist(points[i], points[start], points[end])

            if d > max_dist:
                max_dist = d
                max_idx = i

        if max_dist <= tolerance:
            return

        keep[max_idx] = True
        Polyline._simplify_rdp(points, start, max_idx, tolerance, keep)
        Polyline._simplify_rdp(points, max_idx, end, tolerance, keep)
