from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all


# ═══════════════════════════════════════════════════════════════════════════
# TreeNode
# ═══════════════════════════════════════════════════════════════════════════
@MINI_TEST("TreeNode", "Constructor")
def test_treenode_constructor():
    from session_py import TreeNode
    from session_py import Color

    n0 = TreeNode()
    n = TreeNode("my_named_node")
    n.color = Color(1.0, 0.0, 0.0, 1.0)
    nstr = str(n)
    nother = TreeNode("my_named_node")

    MINI_CHECK(n0.name == "my_node")
    MINI_CHECK(n0.guid)
    MINI_CHECK(n.name == "my_named_node")
    MINI_CHECK(n.color is not None and n.color.r == 1.0)
    MINI_CHECK("TreeNode(my_named_node" in nstr)
    MINI_CHECK(n == n)
    MINI_CHECK(n != nother)


@MINI_TEST("TreeNode", "Json Roundtrip")
def test_treenode_json_roundtrip():
    from session_py import TreeNode
    from session_py.file_encoders import file_json_dump
    from session_py.file_encoders import file_json_load
    from pathlib import Path

    original = TreeNode("test_node")
    child = TreeNode("child_node")
    original.add(child)

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_treenode.json"
    file_json_dump(original, fname)
    loaded = file_json_load(fname)

    MINI_CHECK(loaded.name == original.name)
    MINI_CHECK(len(loaded.children) == 1)
    MINI_CHECK(loaded.children[0].name == "child_node")


@MINI_TEST("TreeNode", "Is Root")
def test_treenode_is_root():
    from session_py import TreeNode

    root = TreeNode("root")
    child = TreeNode("child")
    root.add(child)

    MINI_CHECK(root.is_root)
    MINI_CHECK(not child.is_root)


@MINI_TEST("TreeNode", "Is Leaf")
def test_treenode_is_leaf():
    from session_py import TreeNode

    parent = TreeNode("parent")
    child = TreeNode("child")
    parent.add(child)

    MINI_CHECK(child.is_leaf)
    MINI_CHECK(not parent.is_leaf)


@MINI_TEST("TreeNode", "Add")
def test_treenode_add():
    from session_py import TreeNode

    parent = TreeNode("parent")
    child = TreeNode("child")
    parent.add(child)
    parent.add(parent)

    MINI_CHECK(len(parent.children) == 1)
    MINI_CHECK(child.parent is parent)


@MINI_TEST("TreeNode", "Remove")
def test_treenode_remove():
    from session_py import TreeNode

    parent = TreeNode("parent")
    child = TreeNode("child")
    parent.add(child)
    removed = parent.remove(child)

    MINI_CHECK(removed is child)
    MINI_CHECK(len(parent.children) == 0)
    MINI_CHECK(child.parent is None)


@MINI_TEST("TreeNode", "Parent")
def test_treenode_parent():
    from session_py import TreeNode

    root = TreeNode("root")
    child = TreeNode("child")
    root.add(child)

    MINI_CHECK(root.parent is None)
    MINI_CHECK(child.parent is root)


@MINI_TEST("TreeNode", "Ancestors")
def test_treenode_ancestors():
    from session_py import TreeNode

    root = TreeNode("root")
    mid = TreeNode("mid")
    leaf = TreeNode("leaf")
    root.add(mid)
    mid.add(leaf)

    anc = list(leaf.ancestors)

    MINI_CHECK(len(anc) == 2)
    MINI_CHECK(anc[0].name == "mid")
    MINI_CHECK(anc[1].name == "root")


@MINI_TEST("TreeNode", "Descendants")
def test_treenode_descendants():
    from session_py import TreeNode

    root = TreeNode("root")
    mid = TreeNode("mid")
    leaf = TreeNode("leaf")
    root.add(mid)
    mid.add(leaf)

    desc = root.descendants()

    MINI_CHECK(len(desc) == 2)
    MINI_CHECK(desc[0].name == "mid")
    MINI_CHECK(desc[1].name == "leaf")


@MINI_TEST("TreeNode", "Children")
def test_treenode_children():
    from session_py import TreeNode

    parent = TreeNode("parent")
    c1 = TreeNode("c1")
    c2 = TreeNode("c2")
    parent.add(c1)
    parent.add(c2)

    kids = parent.children

    MINI_CHECK(len(kids) == 2)
    MINI_CHECK(kids[0].name == "c1")
    MINI_CHECK(kids[1].name == "c2")


@MINI_TEST("TreeNode", "Traverse")
def test_treenode_traverse():
    from session_py import TreeNode

    root = TreeNode("root")
    a = TreeNode("a")
    b = TreeNode("b")
    root.add(a)
    root.add(b)

    preorder = list(root.traverse("depthfirst", "preorder"))
    postorder = list(root.traverse("depthfirst", "postorder"))
    bfs = list(root.traverse("breadthfirst", "preorder"))

    MINI_CHECK(len(preorder) == 3 and preorder[0].name == "root")
    MINI_CHECK(len(postorder) == 3 and postorder[2].name == "root")
    MINI_CHECK(len(bfs) == 3 and bfs[0].name == "root")


@MINI_TEST("TreeNode", "Set Dead")
def test_treenode_set_dead():
    from session_py import TreeNode

    p = TreeNode("p")
    a = TreeNode("a")
    b = TreeNode("b")
    c = TreeNode("c")
    d = TreeNode("d")
    p.add(a)
    p.add(b)
    p.add(c)
    b.add(d)
    b.set_dead(True)
    kids = p.children
    ancestors = d.ancestors

    MINI_CHECK(len(kids) == 2 and kids[0] is a and kids[1] is c)
    MINI_CHECK(b.is_dead() and b.parent is None)
    MINI_CHECK(b.children[0] is d)
    MINI_CHECK(d.parent is b)
    MINI_CHECK(len(ancestors) == 1 and ancestors[0] is b)
    MINI_CHECK(not p.is_leaf)

    a.set_dead(True)
    c.set_dead(True)

    MINI_CHECK(p.is_leaf)

    a.set_dead(False)
    b.set_dead(False)
    c.set_dead(False)
    kids = p.children

    MINI_CHECK(len(kids) == 3 and kids[1] is b)
    MINI_CHECK(b.parent is p)


@MINI_TEST("TreeNode", "Compact")
def test_treenode_compact():
    from session_py import TreeNode
    from session_py.history import Tomb
    import sys

    p = TreeNode("p")
    kids = []

    for i in range(6):
        kids.append(TreeNode(f"c{i}"))
        p.add(kids[i])

    tomb = Tomb("", False, 0, kids[3])
    kids[1].set_dead(True)
    kids[3].set_dead(True)
    kids[4].set_dead(True)
    kids[3].set_tomb(tomb)
    before = p.children
    p.compact()
    after = p.children
    raw = p.compact_step(sys.maxsize)
    q = TreeNode("q")
    q.add(kids[5])
    moved = p.children
    same = len(after) == len(before)

    for x, y in zip(after, before):
        same = same and x is y

    MINI_CHECK(raw == 4 and not p.is_compacting())
    MINI_CHECK(len(after) == 3 and same)
    MINI_CHECK(kids[3].is_dead() and kids[3].get_tomb() is tomb)
    MINI_CHECK(kids[1].get_tomb() is None)
    MINI_CHECK(len(moved) == 2 and moved[0] is kids[0] and moved[1] is kids[2])


@MINI_TEST("TreeNode", "Add Moves")
def test_treenode_add_moves():
    from session_py import Tree
    from session_py import TreeNode

    tree = Tree("t")
    root = TreeNode("root")
    p1 = TreeNode("p1")
    p2 = TreeNode("p2")
    w = TreeNode("w")
    x = TreeNode("x")
    z = TreeNode("z")
    y = TreeNode("y")
    tree.add(root)
    tree.add(p1, root)
    tree.add(p2, root)
    tree.add(w, p1)
    tree.add(x, p1)
    tree.add(z, p1)
    tree.add(y, x)
    count = len(tree.nodes)
    ghost = p2.add(x)
    again = p2.add(x)
    old = p1.children
    new = p2.children

    MINI_CHECK(ghost.is_dead() and ghost.name == "")
    MINI_CHECK(len(old) == 2 and old[0] is w and old[1] is z)
    MINI_CHECK(new[-1] is x)
    MINI_CHECK(x.parent is p2)
    MINI_CHECK(y.parent is x)
    MINI_CHECK(len(tree.nodes) == count)
    MINI_CHECK(again is None and len(new) == 1)


# ═══════════════════════════════════════════════════════════════════════════
# Tree
# ═══════════════════════════════════════════════════════════════════════════
@MINI_TEST("Tree", "Constructor")
def test_tree_constructor():
    from session_py import Tree

    t0 = Tree()
    t = Tree("my_named_tree")
    tstr = str(t)

    MINI_CHECK(t0.name == "my_tree")
    MINI_CHECK(t0.guid)
    MINI_CHECK(t.name == "my_named_tree")
    MINI_CHECK("Tree" in tstr)


@MINI_TEST("Tree", "Json Roundtrip")
def test_tree_json_roundtrip():
    from session_py import Tree
    from session_py import TreeNode
    from pathlib import Path

    original = Tree("test_tree")
    root_node = TreeNode("root_node")
    original.add(root_node)

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_tree.json"
    original.file_json_dump(fname)
    loaded = Tree.file_json_load(fname)

    MINI_CHECK(loaded.name == original.name)
    MINI_CHECK(len(list(loaded.nodes)) == len(list(original.nodes)))


@MINI_TEST("Tree", "Protobuf Roundtrip")
def test_tree_protobuf_roundtrip():
    from session_py import Tree
    from session_py import TreeNode
    from pathlib import Path

    original = Tree("test_tree")
    root_node = TreeNode("root_node")
    original.add(root_node)

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_tree.bin"
    original.pb_dump(fname)
    loaded = Tree.pb_load(fname)

    MINI_CHECK(loaded.name == original.name)
    MINI_CHECK(len(list(loaded.nodes)) == len(list(original.nodes)))


@MINI_TEST("Tree", "Root")
def test_tree_root():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    t.add(root)

    MINI_CHECK(t.root is root)


@MINI_TEST("Tree", "Add")
def test_tree_add():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    child = TreeNode("child")
    t.add(root)
    t.add(child, root)

    MINI_CHECK(len(list(t.nodes)) == 2)


@MINI_TEST("Tree", "Nodes")
def test_tree_nodes():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    child = TreeNode("child")
    t.add(root)
    t.add(child, root)

    all_nodes = list(t.nodes)

    MINI_CHECK(len(all_nodes) == 2)
    MINI_CHECK(all_nodes[0].name == "root")
    MINI_CHECK(all_nodes[1].name == "child")


@MINI_TEST("Tree", "Remove")
def test_tree_remove():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    child = TreeNode("child")
    t.add(root)
    t.add(child, root)
    t.remove(child)

    MINI_CHECK(len(list(t.nodes)) == 1)


@MINI_TEST("Tree", "Leaves")
def test_tree_leaves():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    a = TreeNode("a")
    b = TreeNode("b")
    t.add(root)
    t.add(a, root)
    t.add(b, root)

    lvs = list(t.leaves)

    MINI_CHECK(len(lvs) == 2)
    MINI_CHECK(lvs[0].name == "a")
    MINI_CHECK(lvs[1].name == "b")


@MINI_TEST("Tree", "Traverse")
def test_tree_traverse():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    a = TreeNode("a")
    b = TreeNode("b")
    t.add(root)
    t.add(a, root)
    t.add(b, root)

    preorder = list(t.traverse("depthfirst", "preorder"))
    bfs = list(t.traverse("breadthfirst", "preorder"))

    MINI_CHECK(len(preorder) == 3 and preorder[0].name == "root")
    MINI_CHECK(len(bfs) == 3 and bfs[0].name == "root")


@MINI_TEST("Tree", "Get Node By Name")
def test_tree_get_node_by_name():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    child = TreeNode("target")
    t.add(root)
    t.add(child, root)

    found = t.get_node_by_name("target")

    MINI_CHECK(found is not None and found.name == "target")
    MINI_CHECK(t.get_node_by_name("missing") is None)


@MINI_TEST("Tree", "Get Nodes By Name")
def test_tree_get_nodes_by_name():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    a = TreeNode("dup")
    b = TreeNode("dup")
    t.add(root)
    t.add(a, root)
    t.add(b, root)

    found = t.get_nodes_by_name("dup")

    MINI_CHECK(len(found) == 2)


@MINI_TEST("Tree", "Find Node By Guid")
def test_tree_find_node_by_guid():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    t.add(root)
    root_guid = root.guid

    found = t.find_node_by_guid(root_guid)

    MINI_CHECK(found is not None and found.guid == root_guid)
    MINI_CHECK(t.find_node_by_guid("missing-guid") is None)


@MINI_TEST("Tree", "Add Child By Guid")
def test_tree_add_child_by_guid():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    a = TreeNode("a")
    b = TreeNode("b")
    t.add(root)
    t.add(a, root)
    t.add(b, root)
    ok = t.add_child_by_guid(a.guid, b.guid)
    cycle = t.add_child_by_guid(b.guid, a.guid)

    MINI_CHECK(ok)
    MINI_CHECK(not cycle)
    MINI_CHECK(len(a.children) == 1)


@MINI_TEST("Tree", "Get Children Guids")
def test_tree_get_children_guids():
    from session_py import Tree
    from session_py import TreeNode

    t = Tree("t")
    root = TreeNode("root")
    a = TreeNode("a")
    b = TreeNode("b")
    t.add(root)
    t.add(a, root)
    t.add(b, root)

    guids = t.get_children_guids(root.guid)

    MINI_CHECK(len(guids) == 2)
    MINI_CHECK(guids[0] == a.guid)
    MINI_CHECK(guids[1] == b.guid)


@MINI_TEST("Tree", "Dead Nodes")
def test_tree_dead_nodes():
    from session_py import Tree
    from session_py import TreeNode

    tree = Tree("t")
    root = TreeNode("root")
    g = TreeNode("group")
    a = TreeNode("alpha")
    b = TreeNode("beta")
    c = TreeNode("gamma")
    d = TreeNode("delta")
    tree.add(root)
    tree.add(g, root)
    tree.add(a, g)
    tree.add(b, g)
    tree.add(c, b)
    tree.add(d, g)
    b.set_dead(True)
    b_guid = b.guid
    c_guid = c.guid
    g_guid = g.guid

    json = tree.file_json_dumps()
    from_json = Tree.file_json_loads(json)
    from_pb = Tree.pb_loads(tree.pb_dumps())
    expected = ["root", "group", "alpha", "delta"]
    orders = [
        tree.nodes,
        tree.traverse("depthfirst", "preorder"),
        tree.traverse("breadthfirst", "preorder"),
        from_json.nodes,
        from_pb.nodes,
    ]
    ordered = True

    for nodes in orders:
        names = []

        for node in nodes:
            names.append(node.name)

        ordered = ordered and names == expected

    leaves = []

    for node in tree.leaves:
        leaves.append(node.name)

    MINI_CHECK(ordered)
    MINI_CHECK(leaves == ["alpha", "delta"])
    MINI_CHECK(
        tree.get_node_by_name("beta") is None and tree.get_nodes_by_name("gamma") == []
    )
    MINI_CHECK(
        tree.find_node_by_guid(b_guid) is None
        and tree.find_node_by_guid(c_guid) is None
    )
    MINI_CHECK(len(tree.get_children_guids(g_guid)) == 2)
    MINI_CHECK("beta" not in str(tree) and "gamma" not in str(tree))
    MINI_CHECK(
        repr(tree) == "Tree(t, 4 nodes)" and str(g) == "TreeNode(group, 2 children)"
    )
    MINI_CHECK("beta" not in json and "gamma" not in json)


if __name__ == "__main__":
    run_all(language="python")
