from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all
from .tolerance import TOLERANCE


@MINI_TEST("OBB", "Constructor")
def test_obb_constructor():
    from session_py import OBB
    from session_py import Point
    from session_py import Vector

    bb1 = OBB.from_point(Point(5.0, 5.0, 5.0), 2.0)

    MINI_CHECK(TOLERANCE.is_close(bb1.center[0], 5.0))
    MINI_CHECK(TOLERANCE.is_close(bb1.half_size[0], 2.0))

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(2.0, 3.0, 4.0),
    ]
    bb2 = OBB.from_points(pts)
    mn = bb2.min_point()
    mx = bb2.max_point()

    MINI_CHECK(TOLERANCE.is_close(mn[0], 0.0) and TOLERANCE.is_close(mn[2], 0.0))
    MINI_CHECK(TOLERANCE.is_close(mx[0], 2.0) and TOLERANCE.is_close(mx[2], 4.0))

    box = OBB(
        center=Point(0.0, 0.0, 0.0),
        x_axis=Vector(1.0, 0.0, 0.0),
        y_axis=Vector(0.0, 1.0, 0.0),
        z_axis=Vector(0.0, 0.0, 1.0),
        half_size=Vector(1.0, 2.0, 3.0),
    )

    MINI_CHECK(TOLERANCE.is_close(box.half_size[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(box.half_size[1], 2.0))
    MINI_CHECK(TOLERANCE.is_close(box.half_size[2], 3.0))

    same = box.duplicate()

    MINI_CHECK(box == same)
    MINI_CHECK(box != bb1)
    MINI_CHECK(box.guid != same.guid)
    MINI_CHECK(
        str(box)
        == "0.000000, 0.000000, 0.000000\n1.000000, 0.000000, 0.000000\n0.000000, 1.000000, 0.000000\n0.000000, 0.000000, 1.000000\n1.000000, 2.000000, 3.000000"
    )
    MINI_CHECK(
        repr(box)
        == "OBB(my_obb, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 1.000000, 2.000000, 3.000000)"
    )

    bb_aabb = bb2.aabb()

    MINI_CHECK(TOLERANCE.is_close(bb_aabb.min_point()[0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(bb_aabb.max_point()[2], 4.0))

    corners = bb2.corners()

    MINI_CHECK(len(corners) == 8)

    p_center = bb2.point_at(0.0, 0.0, 0.0)
    hx = bb2.half_size[0]
    hy = bb2.half_size[1]
    hz = bb2.half_size[2]
    p_max_pt = bb2.point_at(hx, hy, hz)

    MINI_CHECK(
        TOLERANCE.is_close(p_center[0], 1.0) and TOLERANCE.is_close(p_center[2], 2.0)
    )
    MINI_CHECK(
        TOLERANCE.is_close(p_max_pt[0], 2.0) and TOLERANCE.is_close(p_max_pt[2], 4.0)
    )

    bb3 = OBB.from_points(
        [
            Point(0.0, 0.0, 0.0),
            Point(2.0, 2.0, 2.0),
        ]
    )
    bb3.inflate(1.0)

    MINI_CHECK(TOLERANCE.is_close(bb3.min_point()[0], -1.0))
    MINI_CHECK(TOLERANCE.is_close(bb3.max_point()[0], 3.0))

    bb1.name = "test_bbox"

    MINI_CHECK(bb1.guid != "")
    MINI_CHECK(bb1.name == "test_bbox")


@MINI_TEST("OBB", "Collision")
def test_obb_collision():
    from session_py import OBB
    from session_py import Point

    bb1 = OBB.from_point(Point(0.0, 0.0, 0.0), 1.0)
    bb2 = OBB.from_point(Point(1.5, 0.0, 0.0), 1.0)
    bb3 = OBB.from_point(Point(5.0, 5.0, 5.0), 0.5)

    MINI_CHECK(bb1.collides_with(bb2))
    MINI_CHECK(not bb1.collides_with(bb3))
    MINI_CHECK(bb1.collides_with_broad(bb2))
    MINI_CHECK(not bb1.collides_with_broad(bb3))
    MINI_CHECK(bb1.collides_with_rtcd(bb2))
    MINI_CHECK(not bb1.collides_with_rtcd(bb3))
    MINI_CHECK(bb1.collides_with_naive(bb2))
    MINI_CHECK(not bb1.collides_with_naive(bb3))


@MINI_TEST("OBB", "Transformation")
def test_obb_transformation():
    from session_py import OBB
    from session_py import Point
    from session_py import Xform

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(1.0, 1.0, 0.0),
    ]
    bb = OBB.from_points(pts)
    bb_xf = Xform.translation(0.0, 0.0, 5.0)
    bbt = bb.transformed(bb_xf)

    MINI_CHECK(TOLERANCE.is_close(bbt.center[2], 5.0))

    bb.transform(bb_xf)

    MINI_CHECK(TOLERANCE.is_close(bb.center[2], 5.0))


@MINI_TEST("OBB", "Json Roundtrip")
def test_obb_json_roundtrip():
    from session_py import OBB
    from session_py import Point
    from pathlib import Path

    bb = OBB.from_point(Point(1.0, 2.0, 3.0), 5.0)
    bb.name = "test_bbox"

    data = bb.__jsondump__()
    loaded_j = OBB.__jsonload__(data)

    MINI_CHECK(loaded_j.name == "test_bbox")
    MINI_CHECK(TOLERANCE.is_close(loaded_j.center[0], 1.0))

    text = bb.file_json_dumps()
    loaded_s = OBB.file_json_loads(text)

    MINI_CHECK(loaded_s.name == "test_bbox")
    MINI_CHECK(TOLERANCE.is_close(loaded_s.half_size[0], 5.0))

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_obb.json"
    bb.file_json_dump(fname)

    loaded = OBB.file_json_load(fname)

    MINI_CHECK(loaded.name == "test_bbox")
    MINI_CHECK(TOLERANCE.is_close(loaded.center[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(loaded.half_size[0], 5.0))


@MINI_TEST("OBB", "Protobuf Roundtrip")
def test_obb_protobuf_roundtrip():
    from session_py import OBB
    from session_py import Point
    from pathlib import Path

    bb = OBB.from_point(Point(1.0, 2.0, 3.0), 5.0)
    bb.name = "test_bbox_proto"

    guid = bb.guid
    data = bb.pb_dumps()
    loaded_s = OBB.pb_loads(data)
    proto = bb.to_proto()
    converted = OBB.from_proto(proto)

    MINI_CHECK(loaded_s.name == "test_bbox_proto")
    MINI_CHECK(loaded_s.guid == guid)
    MINI_CHECK(TOLERANCE.is_close(loaded_s.center[0], 1.0))
    MINI_CHECK(proto.guid == guid)
    MINI_CHECK(converted == bb)
    MINI_CHECK(converted.guid == guid)

    fname = Path(__file__).resolve().parents[2] / "serialization" / "test_obb.bin"
    bb.pb_dump(fname)

    loaded = OBB.pb_load(fname)

    MINI_CHECK(loaded.name == "test_bbox_proto")
    MINI_CHECK(loaded.guid == guid)
    MINI_CHECK(TOLERANCE.is_close(loaded.center[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(loaded.half_size[0], 5.0))


@MINI_TEST("OBB", "Accessors")
def test_obb_accessors():
    import math
    from session_py import OBB
    from session_py import Point

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(2.0, 0.0, 0.0),
        Point(2.0, 4.0, 0.0),
        Point(0.0, 4.0, 0.0),
        Point(0.0, 0.0, 6.0),
        Point(2.0, 4.0, 6.0),
    ]
    b = OBB.from_points(pts)

    MINI_CHECK(TOLERANCE.is_close(b.area(), 88.0))
    MINI_CHECK(TOLERANCE.is_close(b.diagonal(), 2.0 * math.sqrt(14.0)))
    MINI_CHECK(b.is_valid())
    MINI_CHECK(TOLERANCE.is_close(b.volume(), 48.0))

    MINI_CHECK(b.closest_point(Point(1.0, 2.0, 3.0)) == Point(1.0, 2.0, 3.0))
    MINI_CHECK(b.closest_point(Point(10.0, 2.0, 3.0)) == Point(2.0, 2.0, 3.0))
    MINI_CHECK(b.contains(Point(1.0, 2.0, 3.0)))
    MINI_CHECK(not b.contains(Point(10.0, 2.0, 3.0)))

    MINI_CHECK(b.corner(False, False, False) == Point(0.0, 0.0, 0.0))
    MINI_CHECK(b.corner(True, True, True) == Point(2.0, 4.0, 6.0))
    MINI_CHECK(len(b.get_corners()) == 8)
    MINI_CHECK(len(b.get_edges()) == 12)

    other = OBB.from_point(Point(5.0, 2.0, 3.0), 1.0)
    b.union_with(other)

    MINI_CHECK(TOLERANCE.is_close(b.half_size[0], 3.0))


@MINI_TEST("OBB", "From Geometry")
def test_obb_from_geometry():
    from session_py import AABB
    from session_py import Color
    from session_py import Line
    from session_py import NurbsCurve
    from session_py import NurbsSurface
    from session_py import OBB
    from session_py import Point
    from session_py import PointCloud
    from session_py import Polyline
    from session_py import Primitives
    from session_py import Vector

    bb_aabb = OBB.from_aabb(AABB(1.0, 2.0, 3.0, 0.5, 1.0, 1.5))

    MINI_CHECK(bb_aabb.center == Point(1.0, 2.0, 3.0))
    MINI_CHECK(TOLERANCE.is_close(bb_aabb.half_size[2], 1.5))
    MINI_CHECK(TOLERANCE.is_close(bb_aabb.x_axis[0], 1.0))

    bb_line = OBB.from_line(Line(0.0, 0.0, 0.0, 4.0, 0.0, 0.0), 0.1)

    MINI_CHECK(bb_line.is_valid())
    MINI_CHECK(TOLERANCE.is_close(bb_line.center[0], 2.0))

    bb_pl = OBB.from_polyline(
        Polyline(
            [
                Point(0.0, 0.0, 0.0),
                Point(4.0, 0.0, 0.0),
                Point(4.0, 4.0, 4.0),
            ]
        ),
        0.0,
    )

    MINI_CHECK(bb_pl.is_valid())
    MINI_CHECK(bb_pl.volume() > 0.0)

    bb_mesh = OBB.from_mesh(Primitives.cube(2.0), 0.0)

    MINI_CHECK(bb_mesh.is_valid())
    MINI_CHECK(TOLERANCE.is_close(bb_mesh.center[0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(bb_mesh.volume(), 8.0))

    bb_pc = OBB.from_pointcloud(
        PointCloud(
            [
                Point(0.0, 0.0, 0.0),
                Point(2.0, 0.0, 0.0),
                Point(0.0, 2.0, 0.0),
                Point(0.0, 0.0, 2.0),
            ],
            [
                Vector(0.0, 0.0, 1.0),
                Vector(0.0, 0.0, 1.0),
                Vector(0.0, 0.0, 1.0),
                Vector(0.0, 0.0, 1.0),
            ],
            [
                Color(255, 0, 0, 255),
                Color(0, 255, 0, 255),
                Color(0, 0, 255, 255),
                Color(255, 255, 0, 255),
            ],
        ),
        0.0,
    )

    MINI_CHECK(bb_pc.is_valid())
    MINI_CHECK(bb_pc.volume() > 0.0)

    bb_nc = OBB.from_nurbscurve(
        NurbsCurve.create(
            False,
            2,
            [
                Point(0.0, 0.0, 0.0),
                Point(1.0, 0.0, 0.0),
                Point(2.0, 0.0, 0.0),
                Point(3.0, 0.0, 0.0),
            ],
        ),
        0.5,
        False,
    )

    MINI_CHECK(bb_nc.is_valid())

    bb_ns = OBB.from_nurbssurface(
        NurbsSurface.create(
            False,
            False,
            1,
            1,
            2,
            2,
            [
                Point(0.0, 0.0, 0.0),
                Point(2.0, 0.0, 0.0),
                Point(0.0, 2.0, 0.0),
                Point(2.0, 2.0, 2.0),
            ],
        ),
        0.0,
    )

    MINI_CHECK(bb_ns.is_valid())


@MINI_TEST("OBB", "From Plane")
def test_obb_from_plane():
    from session_py import OBB
    from session_py import Plane
    from session_py import Point

    plane = Plane.xy_plane()
    box = OBB.from_plane(plane, 2.0, 3.0, 4.0)

    MINI_CHECK(TOLERANCE.is_close(box.half_size[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(box.half_size[1], 1.5))
    MINI_CHECK(TOLERANCE.is_close(box.half_size[2], 2.0))
    MINI_CHECK(box.center == Point(0.0, 0.0, 0.0))

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(2.0, 0.0, 0.0),
        Point(2.0, 3.0, 0.0),
        Point(0.0, 3.0, 0.0),
    ]
    bb = OBB.from_points(pts, 0.0, plane)

    MINI_CHECK(TOLERANCE.is_close(bb.half_size[0], 1.0))
    MINI_CHECK(TOLERANCE.is_close(bb.half_size[1], 1.5))
    MINI_CHECK(TOLERANCE.is_close(bb.x_axis[0], 1.0))


@MINI_TEST("OBB", "Two Rectangles")
def test_obb_two_rectangles():
    from session_py import OBB
    from session_py import Point
    from session_py import Vector

    bb = OBB(
        center=Point(1.0, 2.0, 3.0),
        x_axis=Vector(1.0, 0.0, 0.0),
        y_axis=Vector(0.0, 1.0, 0.0),
        z_axis=Vector(0.0, 0.0, 1.0),
        half_size=Vector(2.0, 3.0, 4.0),
    )
    rects = bb.two_rectangles()

    MINI_CHECK(len(rects) == 10)
    MINI_CHECK(rects[0] == Point(3.0, 5.0, -1.0))
    MINI_CHECK(rects[2] == Point(-1.0, -1.0, -1.0))
    MINI_CHECK(rects[4] == rects[0])
    MINI_CHECK(rects[5] == Point(3.0, 5.0, 7.0))
    MINI_CHECK(rects[7] == Point(-1.0, -1.0, 7.0))
    MINI_CHECK(rects[9] == rects[5])


@MINI_TEST("OBB", "Is Visible Round Trip")
def test_obb_is_visible_round_trip():
    from session_py import OBB
    from session_py import Point

    hidden = OBB.from_point(Point(1.0, 2.0, 3.0), 5.0)

    MINI_CHECK(hidden.is_visible)

    hidden.is_visible = False
    json = OBB.file_json_loads(hidden.file_json_dumps())
    proto = OBB.pb_loads(hidden.pb_dumps())

    MINI_CHECK(not json.is_visible)
    MINI_CHECK(not proto.is_visible)


@MINI_TEST("OBB", "Is Locked Round Trip")
def test_obb_is_locked_round_trip():
    from session_py import OBB
    from session_py import Point

    locked = OBB.from_point(Point(1.0, 2.0, 3.0), 5.0)

    MINI_CHECK(not locked.is_locked)

    locked.is_locked = True
    json = OBB.file_json_loads(locked.file_json_dumps())
    proto = OBB.pb_loads(locked.pb_dumps())

    MINI_CHECK(json.is_locked)
    MINI_CHECK(proto.is_locked)


if __name__ == "__main__":
    run_all(language="python")
