from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable

from .color import Color
from .line import Line
from .matrix import Matrix
from .mesh import Mesh
from .point import Point
from .polyline import Polyline
from .session import Session
from .xform import Xform


def sub(base: str, value: object) -> str:
    """Return text with a Unicode subscript, for example sub('n', 0)."""
    table = str.maketrans("0123456789+-=()aeoxhklmnpst", "₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₒₓₕₖₗₘₙₚₛₜ")
    return base + str(value).translate(table)


def sup(base: str, value: object) -> str:
    """Return text with a Unicode superscript, for example sup('L', -1)."""
    table = str.maketrans("0123456789+-=()in", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁱⁿ")
    return base + str(value).translate(table)


def _color(value: Color | str | Iterable[float]) -> Color:
    if isinstance(value, Color):
        return value
    if isinstance(value, str):
        text = value.lstrip("#")
        if len(text) not in (6, 8):
            raise ValueError("colors are #RRGGBB, #RRGGBBAA, RGB(A) floats, or Color")
        channels = [int(text[i : i + 2], 16) / 255 for i in range(0, len(text), 2)]
        return Color(*channels)
    channels = list(value)
    if len(channels) == 3:
        channels.append(1.0)
    return Color(*channels)


def _rgba(value: Color | str | Iterable[float]) -> list[int]:
    color = _color(value)
    return [round(channel * 255) for channel in (color.r, color.g, color.b, color.a)]


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "step"


def _names(values: tuple) -> list[str]:
    if len(values) == 1 and not isinstance(values[0], str):
        return [str(value) for value in values[0]]
    return [str(value) for value in values]


class Presentation:
    """A sequence of topics whose steps accumulate on a 2D slide plane."""

    def __init__(self, name: str, width: float = 1600, height: float = 760, dark: bool = False, font_size: float | None = None, stroke_scale: float = 1.0, head_scale: float = 1.0, spatial_split: float = 0.56):
        self.name = name
        self.width = float(width)
        self.height = float(height)
        self.dark = bool(dark)
        self.font_size = font_size
        self.stroke_scale = float(stroke_scale)
        self.head_scale = float(head_scale)
        self.spatial_split = float(spatial_split)
        self.topics: list[Topic] = []
        self._links: list[list[str]] = []
        self._gradients: dict[str, dict] = {}
        self._colored: dict[str, list[int]] = {}
        self._spatial: list[str] = []

    def topic(self, title: str) -> Topic:
        topic = Topic(self, title)
        self.topics.append(topic)
        return topic

    def write(self, directory: str | Path) -> Path:
        directory = Path(directory)
        (directory / "steps").mkdir(parents=True, exist_ok=True)
        topics = []
        for ti, topic in enumerate(self.topics):
            steps = []
            for si, step in enumerate(topic.steps):
                items = []
                for fi, (session, arrow) in enumerate(step._files):
                    filename = f"steps/{ti:02d}_{si:02d}_{fi:02d}_{_slug(step.name)}.pb"
                    proto = session.to_proto()
                    if arrow == "line":
                        proto.objects.lines[0].arrowhead = 2
                    elif arrow == "polyline":
                        proto.objects.polylines[0].arrowhead = 2
                    elif arrow == "net3d":
                        for line in proto.objects.lines:
                            if line.name in step._arrow3d:
                                line.arrowhead = 2
                    (directory / filename).write_bytes(
                        proto.SerializeToString(deterministic=True)
                    )
                    items.append({"file": filename, "name": step.name})
                steps.append(
                    {
                        "name": step.name,
                        "caption": step.caption,
                        "items": items,
                        "texts": step._texts
                        if self.font_size is None
                        else [
                            dict(
                                text,
                                height=text["height"] if text.get("spatial") else self.font_size,
                            )
                            for text in step._texts
                        ],
                        "effects": step._effects,
                        "highlight": step._highlight,
                    }
                )
            topics.append({"title": topic.title, "steps": steps})
        document = {
            "name": self.name,
            "width": self.width,
            "height": self.height,
            "dark": self.dark,
            "stroke_scale": self.stroke_scale,
            "head_scale": self.head_scale,
            "spatial_split": self.spatial_split,
            "spatial": self._spatial,
            "topics": topics,
            "links": self._links,
            "gradients": self._gradients,
            "colored": self._colored,
        }
        path = directory / "presentation.yaml"
        path.write_text(
            json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return path

    def show(self, **kwargs):
        from .viewer import show

        return show(self, **kwargs)


class Topic:
    def __init__(self, deck: Presentation, title: str):
        self.deck = deck
        self.title = title
        self.steps: list[Step] = []

    def step(self, name: str, caption: str = "") -> Step:
        step = Step(self, name, caption)
        self.steps.append(step)
        return step


class Step:
    def __init__(self, topic: Topic, name: str, caption: str):
        self.topic = topic
        self.name = name
        self.caption = caption
        self._files: list[tuple[Session, str]] = []
        self._texts: list[dict] = []
        self._effects: list[dict] = []
        self._highlight: list[str] = []
        self._arrow3d: set[str] = set()

    @property
    def deck(self) -> Presentation:
        return self.topic.deck

    def _outline(self, outline: bool | float) -> float:
        if outline is True:
            return 0.0 if self.deck.dark else 2.0
        return float(outline)

    def _xy(self, at: Iterable[float]) -> list[float]:
        values = list(at)
        if len(values) not in (2, 3):
            raise ValueError("a slide point is (x, y) or (x, y, z)")
        return [
            float(values[0]),
            self.deck.height - float(values[1]),
            float(values[2]) if len(values) == 3 else 0.0,
        ]

    def _session(self, name: str) -> Session:
        return Session(f"{self.name}/{name}")

    def _xyz(self, at: Iterable[float]) -> list[float]:
        values = list(at)
        if len(values) not in (2, 3):
            raise ValueError("a 3D point is (x, y) or (x, y, z)")
        return [float(value) for value in values] + [0.0] * (3 - len(values))

    def point3d(self, name: str, at, radius: float = 6, color="#e8edf3") -> str:
        point = Point(*self._xyz(at), name=name)
        point.width = 2 * float(radius)
        point.pointcolor = _color(color)
        session = self._session(name)
        session.add_point(point, None)
        self._files.append((session, ""))
        self.deck._spatial.append(name)
        return name

    def line3d(self, name: str, start, end, width: float = 2, color="#e8edf3", arrow: bool = False, gradient=None) -> str:
        line = Line.from_points(Point(*self._xyz(start)), Point(*self._xyz(end)))
        line.name = name
        line.width = float(width) * self.deck.stroke_scale
        line.linecolor = _color(color)
        session = self._session(name)
        session.add_line(line, None)
        self._files.append((session, "line" if arrow else ""))
        self.deck._spatial.append(name)
        if gradient is not None:
            self.deck._gradients[name] = {"from": _rgba(color), "to": _rgba(gradient)}
        return name

    def arrow3d(self, name: str, start, end, width: float = 2, color="#e8edf3", gradient=None) -> str:
        return self.line3d(name, start, end, width, color, True, gradient)

    def polyline3d(self, name: str, points, width: float = 1, color="#627485", arrow: bool = False, dash=None) -> str:
        polyline = Polyline([Point(*self._xyz(point)) for point in points])
        polyline.name = name
        polyline.width = float(width) * self.deck.stroke_scale
        polyline.linecolor = _color(color)
        polyline.dash = list(dash or [])
        session = self._session(name)
        session.add_polyline(polyline, None)
        self._files.append((session, "polyline" if arrow else ""))
        self.deck._spatial.append(name)
        return name

    def math3d(self, name: str, tex: str, at, size: float = 0.4, color="#e8edf3", center: bool = True, outline: float = -1.5) -> str:
        self._texts.append(
            {
                "name": name,
                "text": tex,
                "at": self._xyz(at),
                "height": float(size),
                "color": _rgba(color),
                "plate": False,
                "outline": self._outline(outline),
                "math": True,
                "center": center,
                "center_ink": center,
                "fixed": True,
                "max_width": 0.0,
                "camera_facing": True,
                "spatial": True,
            }
        )
        self.deck._spatial.append(name)
        return name

    def net3d(self, name: str, nodes, edges, node_colors=None, edge_colors=None, arrows=(), grid: bool = True, labels: bool = True, edge_widths=None, width: float = 5) -> str:
        nodes = [self._xyz(node) for node in nodes]
        session = self._session(name)
        spatial = []
        for index, at in enumerate(nodes):
            color = node_colors[index] if node_colors is not None else "#e8edf3"
            point = Point(*at, name=f"n{index}")
            point.width = 12.0
            point.pointcolor = _color(color)
            session.add_point(point, None)
            spatial.append(point.name)
            if labels:
                offset = (0.2, -0.18, 0.22) if index else (0.3, 0.0, 0.32)
                self.math3d(f"n{index}-label", f"n_{index}", [at[axis] + offset[axis] for axis in range(3)], 0.42, color)
        for index, (start, end) in enumerate(edges):
            color = edge_colors[index] if edge_colors is not None else "#e8edf3"
            line = Line.from_points(Point(*nodes[start]), Point(*nodes[end]))
            line.name = f"e{index}"
            line.width = float(edge_widths[index] if edge_widths is not None else width) * self.deck.stroke_scale
            line.linecolor = _color(color)
            session.add_line(line, None)
            spatial.append(line.name)
            if index in arrows:
                self._arrow3d.add(line.name)
        if grid:
            low = [min(node[axis] for node in nodes) for axis in range(3)]
            high = [max(node[axis] for node in nodes) for axis in range(3)]
            z = low[2] - 0.08
            for axis in (0, 1):
                other = 1 - axis
                for value in range(int(low[axis]) - 1, int(high[axis]) + 2):
                    start = [0.0, 0.0, z]
                    end = [0.0, 0.0, z]
                    start[axis], end[axis] = float(value), float(value)
                    start[other], end[other] = low[other] - 1.0, high[other] + 1.0
                    line = Line.from_points(Point(*start), Point(*end))
                    line.name = f"{name}/grid/{axis}/{value}"
                    line.width = 0.75
                    line.linecolor = _color((0.2, 0.3, 0.38, 0.32))
                    session.add_line(line, None)
                    spatial.append(line.name)
        self._files.append((session, "net3d"))
        self.deck._spatial.extend(spatial)
        return name

    def point(self, name: str, at, radius: float = 5, color="#18232d") -> str:
        point = Point(*self._xy(at), name=name)
        point.width = 2 * float(radius)
        point.pointcolor = _color(color)
        session = self._session(name)
        session.add_point(point, None)
        self._files.append((session, ""))
        return name

    def line(
        self,
        name: str,
        start,
        end,
        width: float = 2,
        color="#18232d",
        arrow: bool = False,
        gradient=None,
    ) -> str:
        line = Line.from_points(Point(*self._xy(start)), Point(*self._xy(end)))
        line.name = name
        line.width = float(width) * self.deck.stroke_scale
        line.linecolor = _color(color)
        session = self._session(name)
        session.add_line(line, None)
        self._files.append((session, "line" if arrow else ""))
        if gradient is not None:
            self.deck._gradients[name] = {"from": _rgba(color), "to": _rgba(gradient)}
        return name

    def arrow(
        self, name: str, start, end, width: float = 2, color="#18232d", gradient=None
    ) -> str:
        return self.line(name, start, end, width, color, True, gradient)

    def polyline(
        self,
        name: str,
        points,
        width: float = 2,
        color="#18232d",
        arrow: bool = False,
        gradient=None,
        dash=None,
    ) -> str:
        polyline = Polyline([Point(*self._xy(point)) for point in points])
        polyline.name = name
        polyline.width = float(width) * self.deck.stroke_scale
        polyline.linecolor = _color(color)
        polyline.dash = list(dash or [])
        session = self._session(name)
        session.add_polyline(polyline, None)
        self._files.append((session, "polyline" if arrow else ""))
        if gradient is not None:
            self.deck._gradients[name] = {"from": _rgba(color), "to": _rgba(gradient)}
        return name

    def mesh(self, name: str, vertices, faces, color="#d9e4ee") -> str:
        mesh = Mesh.from_vertices_and_faces(
            [Point(*self._xy(vertex)) for vertex in vertices],
            [list(face) for face in faces],
        )
        mesh.name = name
        mesh.set_objectcolor(_color(color))
        mesh.set_linecolors([_color((0, 0, 0, 0))] * mesh.number_of_edges())
        session = self._session(name)
        session.add_mesh(mesh, None)
        self._files.append((session, ""))
        return name

    def text(
        self,
        name: str,
        text: str,
        at,
        size: float = 28,
        color="#18232d",
        outline: bool | float = False,
    ) -> str:
        self._texts.append(
            {
                "name": name,
                "text": text,
                "at": self._xy(at),
                "height": float(size),
                "color": _rgba(color),
                "plate": False,
                "outline": self._outline(outline),
            }
        )
        return name

    def math(
        self,
        name: str,
        tex: str,
        at,
        size: float = 28,
        color="#18232d",
        outline: bool | float = False,
        center: bool = False,
        max_width: float = 0.0,
        fixed: bool = False,
        center_ink: bool = False,
    ) -> str:
        self._texts.append(
            {
                "name": name,
                "text": tex,
                "at": self._xy(at),
                "height": float(size),
                "color": _rgba(color),
                "plate": False,
                "outline": self._outline(outline),
                "math": True,
                "center": center,
                "center_ink": center_ink,
                "fixed": fixed,
                "max_width": float(max_width),
            }
        )
        return name

    def fraction(
        self,
        name: str,
        numerator: str,
        denominator: str,
        at,
        size: float = 28,
        color="#18232d",
        outline: bool | float = False,
        lhs: str = "",
    ) -> str:
        tex = rf"\frac{{{numerator}}}{{{denominator}}}"
        if lhs:
            tex = rf"{lhs}={tex}"
        return self.math(name, tex, at, size, color, outline, True)

    def matrix(
        self,
        name: str,
        values,
        at,
        cell: float = 48,
        color="#18232d",
        fill="#eef1f7",
        brackets: bool = True,
        title: str | None = None,
        colored=None,
    ) -> str:
        if self.deck.dark:
            if color == "#18232d":
                color = "#e8edf3"
            if fill == "#eef1f7":
                fill = "#252b35"
        matrix = Matrix.from_rows(
            [
                [
                    float(value) if isinstance(value, (int, float)) else 0.0
                    for value in row
                ]
                for row in values
            ]
        )
        matrix.name = name
        matrix.cell = float(cell)
        matrix.mincolor = _color(fill)
        matrix.maxcolor = _color(fill)
        matrix.zerocolor = _color(fill)
        matrix.textcolor = _color(color)
        matrix.linecolor = _color(color)
        session = self._session(name)
        session.add_matrix(matrix, None)
        session.set_xform(matrix.guid, Xform.translation(*self._xy(at)))
        self._files.append((session, ""))
        x, y = list(at)[:2]
        if title is not None:
            self.math(
                f"{name}/title",
                title,
                (x - cell * 0.5, y - cell * 0.9),
                cell * 0.5,
                color,
                fixed=True,
            )
        for row, entries in enumerate(values):
            for col, value in enumerate(entries):
                tex = value if isinstance(value, str) else f"{value:g}"
                numeric = isinstance(value, (int, float))
                active = (
                    numeric and value != 0
                    if colored is None
                    else bool(colored(row, col, value))
                )
                if active:
                    index = row * len(entries) + col
                    if index >= 64:
                        raise ValueError("colored presentation matrices support at most 64 cells")
                    self.deck._colored.setdefault(name, []).append(index)
                self.math(
                    f"{name}[{row},{col}]",
                    tex,
                    (x + col * cell, y + row * cell),
                    cell * 0.32,
                    "#ffffff" if active else color,
                    center=True,
                    center_ink=True,
                    max_width=cell * 0.82,
                    fixed=True,
                )
        if brackets:
            left = x - cell * 0.72
            right = x + (matrix.cols - 0.28) * cell
            top = y - cell * 0.68
            bottom = y + (matrix.rows - 0.32) * cell
            tick = cell * 0.18
            self.polyline(
                f"{name}/left",
                [
                    (left + tick, top),
                    (left, top),
                    (left, bottom),
                    (left + tick, bottom),
                ],
                2.0,
                color,
            )
            self.polyline(
                f"{name}/right",
                [
                    (right - tick, top),
                    (right, top),
                    (right, bottom),
                    (right - tick, bottom),
                ],
                2.0,
                color,
            )
        return name

    def animate(self, name: str, kind: str = "grow", duration: float = 650) -> str:
        if kind not in ("grow", "pulse", "highlight", "cells"):
            raise ValueError("animation kind is grow, pulse, highlight, or cells")
        self._effects.append(
            {"name": name, "kind": kind, "duration_ms": float(duration)}
        )
        return name

    def morph(self, source: str, target: str, duration_ms: float = 900, delay_ms: float = 0) -> str:
        effect = {
            "name": target,
            "from": source,
            "kind": "morph",
            "duration_ms": float(duration_ms),
        }
        if delay_ms:
            effect["delay_ms"] = float(delay_ms)
        self._effects.append(effect)
        return target

    def move(self, name: str, to, duration_ms: float = 900, delay_ms: float = 0) -> str:
        effect = {
            "name": name,
            "kind": "move",
            "to": self._xyz(to),
            "duration_ms": float(duration_ms),
        }
        if delay_ms:
            effect["delay_ms"] = float(delay_ms)
        self._effects.append(effect)
        return name

    def scale(self, name: str, factor: float, about, duration_ms: float = 900, delay_ms: float = 0) -> str:
        effect = {
            "name": name,
            "kind": "scale",
            "factor": float(factor),
            "about": self._xyz(about),
            "duration_ms": float(duration_ms),
        }
        if delay_ms:
            effect["delay_ms"] = float(delay_ms)
        self._effects.append(effect)
        return name

    def highlight(self, *names) -> Step:
        self._highlight.extend(_names(names))
        return self

    def link(self, *names) -> Step:
        group = _names(names)
        if len(group) < 2:
            raise ValueError("a highlight link needs at least two names")
        if group not in self.deck._links:
            self.deck._links.append(group)
        return self
