import json
import tempfile
from pathlib import Path

from .mini_test import MINI_CHECK
from .mini_test import MINI_TEST


@MINI_TEST("Slides", "Lean deck authoring")
def test_slide_authoring_writes_steps_effects_links_and_symbolic_matrices():
    from session_py import Session
    from session_py.slides import Presentation, sub, sup

    deck = Presentation("Force density")
    topic = deck.topic("Equilibrium")
    step = topic.step("A node", "A free node")
    step.point("n0", (200, 300), radius=7)
    step.arrow("f0", (200, 300), (350, 200), color="#204080", gradient="#dd4040")
    step.text("n0-label", sub("n", 0), (180, 320), outline=True)
    step.fraction("q", "f", "L^{-1}", (600, 240), lhs="q")
    step.matrix("C", [["n_0", 0], [1, "x"]], (900, 240), cell=60)
    step.animate("n0", "pulse", 500)
    step.animate("C", "cells")
    step.morph("q", "q-solved", 900, delay_ms=200)
    step.move("n0", (7.5, -2.5, 0), 900)
    step.scale("f0", 3, (200, 300, 0))
    step.link("f0", "C/0")
    step.highlight("n0")
    other = deck.topic("The trick").step("q = f/L")
    other.text("q-label", "q = f/L", (100, 100))

    with tempfile.TemporaryDirectory() as temporary:
        path = deck.write(temporary)
        document = json.loads(path.read_text(encoding="utf-8"))
        first = document["topics"][0]["steps"][0]
        MINI_CHECK(len(document["topics"]) == 2)
        MINI_CHECK(first["texts"][0]["outline"] == 2.0)
        MINI_CHECK(first["texts"][0]["at"] == [180.0, 440.0, 0.0])
        MINI_CHECK(
            first["effects"][:2]
            == [
                {"name": "n0", "kind": "pulse", "duration_ms": 500.0},
                {"name": "C", "kind": "cells", "duration_ms": 650.0},
            ]
        )
        MINI_CHECK(first["effects"][2:] == [
            {"name": "q-solved", "from": "q", "kind": "morph", "duration_ms": 900.0, "delay_ms": 200.0},
            {"name": "n0", "kind": "move", "to": [7.5, -2.5, 0.0], "duration_ms": 900.0},
            {"name": "f0", "kind": "scale", "factor": 3.0, "about": [200.0, 300.0, 0.0], "duration_ms": 900.0},
        ])
        MINI_CHECK(document["links"] == [["f0", "C/0"]])
        entries = {
            text["name"]: text["color"]
            for text in first["texts"]
            if text["name"].startswith("C[")
        }
        MINI_CHECK(entries["C[0,0]"] == [24, 35, 45, 255])
        MINI_CHECK(entries["C[1,0]"] == [255, 255, 255, 255])
        MINI_CHECK(document["colored"]["C"] == [2])
        MINI_CHECK("C[1,0]" not in first["highlight"])
        MINI_CHECK(document["gradients"]["f0"]["to"] == [221, 64, 64, 255])
        MINI_CHECK(
            any(
                text["text"] == "n_0" and text["math"] and text["center"]
                for text in first["texts"]
            )
        )
        MINI_CHECK(
            any(
                text["text"] == "q=\\frac{f}{L^{-1}}" and text["math"]
                for text in first["texts"]
            )
        )
        from session_py.proto import session_pb2

        arrow = session_pb2.Session()
        arrow.ParseFromString(
            (Path(temporary) / first["items"][1]["file"]).read_bytes()
        )
        MINI_CHECK(arrow.objects.lines[0].arrowhead == 2)
        matrix_files = [
            item
            for item in first["items"]
            if Session.pb_load(Path(temporary) / item["file"]).objects.components
        ]
        MINI_CHECK(len(matrix_files) == 1)
        matrix = Session.pb_load(Path(temporary) / matrix_files[0]["file"])
        component = matrix.objects.components[0]
        MINI_CHECK(component.extra["rows"] == 2 and component.extra["cols"] == 2)
        MINI_CHECK(component.extra["data"] == [0.0, 0.0, 1.0, 0.0])
        MINI_CHECK(sub("n", 0) == "n₀" and sup("L", -1) == "L⁻¹")


@MINI_TEST("Slides", "Validation")
def test_slide_validation():
    from session_py.slides import Presentation

    deck = Presentation("x")
    step = deck.topic("t").step("s")
    MINI_CHECK(step.link("a", "b") is step)
    try:
        step.link("a")
        MINI_CHECK(False)
    except ValueError:
        MINI_CHECK(True)
    try:
        step.animate("a", "spin")
        MINI_CHECK(False)
    except ValueError:
        MINI_CHECK(True)


@MINI_TEST("Slides", "Dark theme")
def test_dark_slide_theme():
    from session_py.slides import Presentation

    deck = Presentation("Dark", dark=True, font_size=28)
    step = deck.topic("Theme").step("Dark")
    step.math("label", "x", (100, 100), size=40, outline=True)
    step.matrix("C", [[0, 1]], (300, 100))
    with tempfile.TemporaryDirectory() as temporary:
        document = json.loads(deck.write(temporary).read_text(encoding="utf-8"))
        texts = document["topics"][0]["steps"][0]["texts"]
        MINI_CHECK(document["dark"] is True)
        MINI_CHECK(texts[0]["outline"] == 0.0)
        MINI_CHECK(all(text["height"] == 28 for text in texts))
        MINI_CHECK(all(text.get("fixed") for text in texts if text["name"].startswith("C[")))
        cells = [text for text in texts if text["name"].startswith("C[")]
        MINI_CHECK(all(text["center"] and text["center_ink"] for text in cells))
        MINI_CHECK([text["at"] for text in cells] == [[300.0, 660.0, 0.0], [348.0, 660.0, 0.0]])
        entries = {text["name"]: text["color"] for text in texts}
        MINI_CHECK(entries["C[0,0]"] == [232, 237, 243, 255])
        MINI_CHECK(entries["C[0,1]"] == [255, 255, 255, 255])
